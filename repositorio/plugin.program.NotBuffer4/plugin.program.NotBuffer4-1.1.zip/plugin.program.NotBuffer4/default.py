import xbmc , xbmcaddon , xbmcgui , xbmcplugin , os , sys , xbmcvfs , glob
import shutil
import urllib2 , urllib
import re
import zipfile
import conf
import fnmatch
try : from sqlite3 import dbapi2 as database
except : from pysqlite2 import dbapi2 as database
from datetime import date , datetime , timedelta
from urlparse import urljoin
from resources . libs import extract , downloader , notify , wizard as wiz
if 64 - 64: i11iIiiIii
OO0o = conf . ADDON_ID
Oo0Ooo = conf . ADDONTITLE
O0O0OO0O0O0 = wiz . addonId ( OO0o )
iiiii = wiz . addonInfo ( OO0o , 'version' )
ooo0OO = wiz . addonInfo ( OO0o , 'path' )
II1 = xbmcgui . Dialog ( )
O00ooooo00 = xbmcgui . DialogProgress ( )
I1IiiI = xbmc . translatePath ( 'special://home/' )
IIi1IiiiI1Ii = xbmc . translatePath ( 'special://logpath/' )
I11i11Ii = xbmc . translatePath ( 'special://profile/' )
oO00oOo = os . path . join ( I1IiiI , 'addons' )
OOOo0 = os . path . join ( I1IiiI , 'userdata' )
Oooo000o = os . path . join ( oO00oOo , OO0o )
IiIi11iIIi1Ii = os . path . join ( oO00oOo , 'packages' )
Oo0O = os . path . join ( OOOo0 , 'addon_data' )
IiI = os . path . join ( OOOo0 , 'addon_data' , OO0o )
ooOo = os . path . join ( OOOo0 , 'advancedsettings.xml' )
Oo = os . path . join ( OOOo0 , 'sources.xml' )
o0O = os . path . join ( OOOo0 , 'favourites.xml' )
IiiIII111iI = os . path . join ( OOOo0 , 'profiles.xml' )
IiII = os . path . join ( OOOo0 , 'guisettings.xml' )
iI1Ii11111iIi = os . path . join ( OOOo0 , 'Thumbnails' )
i1i1II = os . path . join ( OOOo0 , 'Database' )
O0oo0OO0 = os . path . join ( ooo0OO , 'fanart.jpg' )
I1i1iiI1 = os . path . join ( ooo0OO , 'icon.png' )
iiIIIII1i1iI = os . path . join ( ooo0OO , 'resources' , 'art' )
o0oO0 = os . path . join ( IiI , 'wizard.log' )
oo00 = xbmc . getSkinDir ( )
o00 = wiz . getS ( 'buildname' )
Oo0oO0ooo = wiz . getS ( 'defaultskin' )
o0oOoO00o = wiz . getS ( 'defaultskinname' )
i1 = wiz . getS ( 'defaultskinignore' )
oOOoo00O0O = wiz . getS ( 'buildversion' )
i1111 = wiz . getS ( 'buildtheme' )
i11 = wiz . getS ( 'latestversion' )
I11 = wiz . getS ( 'installmethod' )
Oo0o0000o0o0 = wiz . getS ( 'show15' )
oOo0oooo00o = wiz . getS ( 'show16' )
oO0o0o0ooO0oO = wiz . getS ( 'show17' )
oo0o0O00 = wiz . getS ( 'show18' )
oO = wiz . getS ( 'adult' )
i1iiIIiiI111 = wiz . getS ( 'showmantenimiento' )
oooOOOOO = wiz . getS ( 'autoclean' )
i1iiIII111ii = wiz . getS ( 'clearcache' )
i1iIIi1 = wiz . getS ( 'clearpackages' )
ii11iIi1I = wiz . getS ( 'clearthumbs' )
iI111I11I1I1 = wiz . getS ( 'autocleanfeq' )
OOooO0OOoo = wiz . getS ( 'nextautocleanup' )
iIii1 = wiz . getS ( 'includevideo' )
oOOoO0 = wiz . getS ( 'includeall' )
O0OoO000O0OO = wiz . getS ( 'includebob' )
iiI1IiI = wiz . getS ( 'includephoenix' )
II = wiz . getS ( 'includespecto' )
ooOoOoo0O = wiz . getS ( 'includegenesis' )
OooO0 = wiz . getS ( 'includeexodus' )
II11iiii1Ii = wiz . getS ( 'includeonechan' )
OO0oOoo = wiz . getS ( 'includesalts' )
O0o0Oo = wiz . getS ( 'includesaltslite' )
Oo00OOOOO = wiz . getS ( 'seperate' )
O0O = wiz . getS ( 'notify' )
O00o0OO = wiz . getS ( 'noteid' )
I11i1 = wiz . getS ( 'notedismiss' )
iIi1ii1I1 = wiz . getS ( 'traktlastsave' )
o0 = wiz . getS ( 'debridlastsave' )
I11II1i = wiz . getS ( 'loginlastsave' )
IIIII = wiz . getS ( 'keepfavourites' )
ooooooO0oo = wiz . getS ( 'keepsources' )
IIiiiiiiIi1I1 = wiz . getS ( 'keepprofiles' )
I1IIIii = wiz . getS ( 'keepadvanced' )
oOoOooOo0o0 = wiz . getS ( 'keeprepos' )
OOOO = wiz . getS ( 'keepsuper' )
OOO00 = wiz . getS ( 'keepwhitelist' )
iiiiiIIii = wiz . getS ( 'keeptrakt' )
O000OO0 = wiz . getS ( 'keepdebrid' )
I11iii1Ii = wiz . getS ( 'keeplogin' )
I11II1i = wiz . getS ( 'loginlastsave' )
I1IIiiIiii = wiz . getS ( 'developer' )
O000oo0O = wiz . getS ( 'enable3rd' )
OOOOi11i1 = wiz . getS ( 'wizard1name' )
IIIii1II1II = wiz . getS ( 'wizard1url' )
i1I1iI = wiz . getS ( 'wizard2name' )
oo0OooOOo0 = wiz . getS ( 'wizard2url' )
o0OO00oO = wiz . getS ( 'wizard3name' )
I11i1I1I = wiz . getS ( 'wizard3url' )
oO0Oo = O0O0OO0O0O0 . getSetting ( 'path' ) if not O0O0OO0O0O0 . getSetting ( 'path' ) == '' else 'special://home/'
oOOoo0Oo = os . path . join ( oO0Oo , 'My_Builds' , '' )
iI111I11I1I1 = int ( float ( iI111I11I1I1 ) ) if iI111I11I1I1 . isdigit ( ) else 0
o00OO00OoO = date . today ( )
OOOO0OOoO0O0 = o00OO00OoO + timedelta ( days = 1 )
O0Oo000ooO00 = o00OO00OoO + timedelta ( days = 2 )
oO0 = o00OO00OoO + timedelta ( days = 3 )
Ii1iIiII1ii1 = o00OO00OoO + timedelta ( days = 5 )
ooOooo000oOO = o00OO00OoO + timedelta ( days = 7 )
Oo0oOOo = float ( xbmc . getInfoLabel ( "System.BuildVersion" ) [ : 4 ] )
Oo0OoO00oOO0o = wiz . mediaCenter ( )
OOO00O = conf . EXCLUDES
OOoOO0oo0ooO = conf . BUILDFILE
O0o0O00Oo0o0 = conf . APKFILE
O00O0oOO00O00 = conf . YOUTUBETITLE
i1Oo00 = conf . YOUTUBEFILE
i1i = conf . ADDONFILE
iiI111I1iIiI = conf . ADVANCEDFILE
IIIi1I1IIii1II = conf . UPDATECHECK if str ( conf . UPDATECHECK ) . isdigit ( ) else 1
O0 = o00OO00OoO + timedelta ( days = IIIi1I1IIii1II )
ii1ii1ii = conf . NOTIFICATION
oooooOoo0ooo = conf . ENABLE
I1I1IiI1 = conf . HEADERMESSAGE
III1iII1I1ii = conf . AUTOUPDATE
oOOo0 = conf . WIZARDFILE
oo00O00oO = conf . HIDECONTACT
iIiIIIi = conf . CONTACT
ooo00OOOooO = conf . CONTACTICON if not conf . CONTACTICON == 'http://' else I1i1iiI1
O00OOOoOoo0O = conf . CONTACTFANART if not conf . CONTACTFANART == 'http://' else O0oo0OO0
O000OOo00oo = conf . HIDESPACERS
oo0OOo = conf . COLOR1
ooOOO00Ooo = conf . COLOR2
IiIIIi1iIi = conf . THEME1
ooOOoooooo = conf . THEME2
II1I = conf . THEME3
O0i1II1Iiii1I11 = conf . THEME4
IIII = conf . THEME5
iiIiI = conf . ICONBUILDS if not conf . ICONBUILDS == 'http://' else I1i1iiI1
o00oooO0Oo = conf . ICONMAINT if not conf . ICONMAINT == 'http://' else I1i1iiI1
o0O0OOO0Ooo = conf . ICONSPEED if not conf . ICONSPEED == 'http://' else I1i1iiI1
iiIiII1 = conf . ICONAPK if not conf . ICONAPK == 'http://' else I1i1iiI1
OOO00O0O = conf . ICONRETRO if not conf . ICONRETRO == 'http://' else I1i1iiI1
iii = conf . ICONADDONS if not conf . ICONADDONS == 'http://' else I1i1iiI1
oOooOOOoOo = conf . ICONYOUTUBE if not conf . ICONYOUTUBE == 'http://' else I1i1iiI1
i1Iii1i1I = conf . ICONSAVE if not conf . ICONSAVE == 'http://' else I1i1iiI1
OOoO00 = conf . ICONTRAKT if not conf . ICONTRAKT == 'http://' else I1i1iiI1
IiI111111IIII = conf . ICONREAL if not conf . ICONREAL == 'http://' else I1i1iiI1
i1Ii = conf . ICONLOGIN if not conf . ICONLOGIN == 'http://' else I1i1iiI1
ii111iI1iIi1 = conf . ICONCONTACT if not conf . ICONCONTACT == 'http://' else I1i1iiI1
OOO = conf . ICONSETTINGS if not conf . ICONSETTINGS == 'http://' else I1i1iiI1
oo0OOo0 = wiz . LOGFILES
#TRAKTID          = traktit.TRAKTID
#DEBRIDID         = debridit.DEBRIDID
#LOGINID          = loginit.LOGINID
if 47 - 47: OoOO000 + IIi11i1i1iI1 . ii / Ii11I1 - Ii1Iiii1I1 . oooO0
def iIiIiiIIiIIi ( ) :
 if O000OOo00oo == 'Yes' : oO0OOOO0 ( wiz . sep ( ) , '' , themeit = II1I )
 if 26 - 26: oO00ooO0o0
 I1i1Iiiii ( 'Utilidades' , 'maint' , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
 if 94 - 94: ooO00ooO000 * o0O00oO + oOI1Ii1I1 % IiII111iI1ii1
 if 37 - 37: OO0OOOOoo0OOO - ii1Ii1I1Ii11i / i1111I1I
 if 13 - 13: oO0OOoo0 . O0o0OO0O00O
 if 19 - 19: ooo + o00oOOooOOo0o / OO0ooOOO0OOO - Ii1Iiii1I1 - o0O00oO * O0o0OO0O00O
 if 69 - 69: OoOO000 . ooO00ooO000
 if 49 - 49: oooO0 - i1111I1I
 oO0OOOO0 ( 'Test de Velocidad' , 'speed' , icon = o0O0OOO0Ooo , themeit = IiIIIi1iIi )
 if 74 - 74: IIi11i1i1iI1 * IiII111iI1ii1 + o0O00oO / Ii11I1 / Ii1Iiii1I1 . oO00ooO0o0
 if 62 - 62: ii * oooO0
 if 58 - 58: o0O00oO % oOI1Ii1I1
 if 50 - 50: o00oOOooOOo0o . oOI1Ii1I1
 if 97 - 97: OoOO000 + o0O00oO
 if 89 - 89: oOI1Ii1I1 + ooO00ooO000 * i1111I1I * oO0OOoo0
 if 37 - 37: ii - OoOO000 - oOI1Ii1I1
 if O000OOo00oo == 'No' : oO0OOOO0 ( wiz . sep ( ) , '' , themeit = II1I )
 oO0OOOO0 ( 'Ajustes' , 'settings' , icon = OOO , themeit = IiIIIi1iIi )
 oO0OOOO0 ( '[I]- Establece tus preferencias[/I] ' , 'grupo' , icon = o0O0OOO0Ooo , themeit = II1I )
 if 77 - 77: ii1Ii1I1Ii11i * IIi11i1i1iI1
 if I1IIiiIiii == 'true' : I1i1Iiiii ( 'Developer Menu' , 'developer' , icon = OOO , themeit = IiIIIi1iIi )
 oO00oOOoooO ( 'files' , 'viewType' )
 if 46 - 46: oooO0 - ii - i1111I1I * Ii1Iiii1I1
 if 34 - 34: i1111I1I - O0o0OO0O00O / ii1Ii1I1Ii11i + IiII111iI1ii1 * oO0OOoo0
 if 73 - 73: o0O00oO . oO0OOoo0 * IiII111iI1ii1 % IiII111iI1ii1 % ii
 if 63 - 63: IIi11i1i1iI1 * i11iIiiIii % IIi11i1i1iI1 * i11iIiiIii
def iI1111iiii ( view = None ) :
 Oo0OO = '[COLOR lime]ON[/COLOR]' ; O0OooOo0o = '[COLOR red]OFF[/COLOR]'
 iiI11ii1I1 = 'true' if oooOOOOO == 'true' else 'false'
 Ooo0OOoOoO0 = 'true' if i1iiIII111ii == 'true' else 'false'
 oOo0OOoO0 = 'true' if i1iIIi1 == 'true' else 'false'
 IIo0Oo0oO0oOO00 = 'true' if ii11iIi1I == 'true' else 'false'
 oo00OO0000oO = 'true' if i1iiIIiiI111 == 'true' else 'false'
 I1II1 = 'true' if iIii1 == 'true' else 'false'
 oooO = 'true' if oOOoO0 == 'true' else 'false'
 i1I1i111Ii = 'true' if O000oo0O == 'true' else 'false'
 if wiz . Grab_Log ( True ) == False : oooi1i1iI1iiiI = 0
 else : oooi1i1iI1iiiI = Ooo0oOooo0 ( wiz . Grab_Log ( True ) , True , True )
 if wiz . Grab_Log ( True , True ) == False : oOOOoo00 = 0
 else : oOOOoo00 = Ooo0oOooo0 ( wiz . Grab_Log ( True , True ) , True , True )
 iiIiIIIiiI = int ( oooi1i1iI1iiiI ) + int ( oOOOoo00 )
 iiI1IIIi = str ( iiIiIIIiiI ) + '[COLOR white] Errores Encontrados ...[/COLOR]' if iiIiIIIiiI > 0 else 'No encontrados'
 II11IiIi11 = ': [COLOR green]No encontrados[/COLOR]' if not os . path . exists ( o0oO0 ) else ": [COLOR gold]%s[/COLOR]" % wiz . convertSize ( os . path . getsize ( o0oO0 ) )
 if 7 - 7: ooO00ooO000 . oO0OOoo0 % OO0OOOOoo0OOO * OO0ooOOO0OOO + ooo + o00oOOooOOo0o
 if 38 - 38: oOI1Ii1I1 - oooO0 - oOI1Ii1I1 / i1111I1I - Ii11I1
 if 1 - 1: Ii1Iiii1I1
 if 68 - 68: O0o0OO0O00O - oooO0 / o00oOOooOOo0o / i1111I1I
 if 12 - 12: oO0OOoo0 + i11iIiiIii * IIi11i1i1iI1 / IiII111iI1ii1 . i1111I1I
 if 5 - 5: Ii11I1 + ooo / oOI1Ii1I1 . O0o0OO0O00O / i1111I1I
 if 32 - 32: oooO0 % IIi11i1i1iI1 / Ii11I1 - oooO0
 if 7 - 7: o00oOOooOOo0o * ooO00ooO000 - OO0ooOOO0OOO + ii1Ii1I1Ii11i * oooO0 % ooO00ooO000
 if 15 - 15: o0O00oO % oooO0 * i1111I1I
 if 81 - 81: OO0ooOOO0OOO - IIi11i1i1iI1 - Ii11I1 / o00oOOooOOo0o - OoOO000 * i1111I1I
 if 20 - 20: OO0OOOOoo0OOO % ooo
 if 19 - 19: IiII111iI1ii1 % ooo + OO0ooOOO0OOO / o00oOOooOOo0o . OO0ooOOO0OOO
 if 12 - 12: Ii11I1 + Ii11I1 - IiII111iI1ii1 * oO00ooO0o0 % oO00ooO0o0 - Ii1Iiii1I1
 if 52 - 52: OO0ooOOO0OOO . O0o0OO0O00O + o00oOOooOOo0o
 if 38 - 38: Ii11I1 - Ii1Iiii1I1 . o00oOOooOOo0o
 if 58 - 58: oooO0 . O0o0OO0O00O + o0O00oO
 if 66 - 66: O0o0OO0O00O / OO0OOOOoo0OOO * ii + ii % i1111I1I
 if 49 - 49: OO0OOOOoo0OOO - i11iIiiIii . o00oOOooOOo0o * oO0OOoo0 % O0o0OO0O00O + Ii11I1
 oOO0OOOo = wiz . getSize ( IiIi11iIIi1Ii )
 oo0o0000 = wiz . getSize ( iI1Ii11111iIi )
 iiI = wiz . getCacheSize ( )
 oOOO0o = oOO0OOOo + oo0o0000 + iiI
 O00oOOooo = [ 'Siempre' , 'A diario' , '2 Dias' , '3 Dias' , '5 Dias' , 'Semanal' ]
 if 50 - 50: IiII111iI1ii1 % OoOO000 * oOI1Ii1I1
 if 5 - 5: ooo * o0O00oO
 I1i1Iiiii ( 'Ver estado:' , 'mantenimiento' , 'clean' , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
 if view == "clean" or i1iiIIiiI111 == 'true' :
  oO0OOOO0 ( 'Limpieza Total: [COLOR gold][B]%s[/B][/COLOR]' % wiz . convertSize ( oOOO0o ) , 'fullclean' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Borra Cache: [COLOR gold][B]%s[/B][/COLOR]' % wiz . convertSize ( iiI ) , 'clearcache' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Borra Packages: [COLOR gold][B]%s[/B][/COLOR]' % wiz . convertSize ( oOO0OOOo ) , 'clearpackages' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Borra Thumbnails: [COLOR gold][B]%s[/B][/COLOR]' % wiz . convertSize ( oo0o0000 ) , 'clearthumb' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Borra iconos desactualizados' , 'oldThumbs' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Borra Crash Logs' , 'clearcrash' , icon = o00oooO0Oo , themeit = II1I )
  if 5 - 5: o00oOOooOOo0o
  if 90 - 90: o00oOOooOOo0o . OO0ooOOO0OOO / oO0OOoo0 - i1111I1I
  if 40 - 40: ii
 I1i1Iiiii ( 'Auto Limpieza' , 'mantenimiento' , 'Auto Clean' , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
 if view == "Auto Clean" or i1iiIIiiI111 == 'true' :
  oO0OOOO0 ( 'Auto Clean' , '' , fanart = O0oo0OO0 , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
  oO0OOOO0 ( 'Limpieza Automatica al inicio: %s' % iiI11ii1I1 . replace ( 'true' , Oo0OO ) . replace ( 'false' , O0OooOo0o ) , 'togglesetting' , 'autoclean' , icon = o00oooO0Oo , themeit = II1I )
 if iiI11ii1I1 == 'true' :
  oO0OOOO0 ( '--- Frecuencia Limpieza Auto: [B][COLOR gold]%s[/COLOR][/B]' % O00oOOooo [ iI111I11I1I1 ] , 'changefeq' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( '--- Borra Cache al inicio: %s' % Ooo0OOoOoO0 . replace ( 'true' , Oo0OO ) . replace ( 'false' , O0OooOo0o ) , 'togglesetting' , 'clearcache' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( '--- Borra Packages al inicio: %s' % oOo0OOoO0 . replace ( 'true' , Oo0OO ) . replace ( 'false' , O0OooOo0o ) , 'togglesetting' , 'clearpackages' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( '--- Borra Thumbnails al inicio: %s' % IIo0Oo0oO0oOO00 . replace ( 'true' , Oo0OO ) . replace ( 'false' , O0OooOo0o ) , 'togglesetting' , 'clearthumbs' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Clear Video Cache' , '' , fanart = O0oo0OO0 , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
  oO0OOOO0 ( 'Incluye Cache de Video en Borrado: %s' % I1II1 . replace ( 'true' , Oo0OO ) . replace ( 'false' , O0OooOo0o ) , 'togglecache' , 'includevideo' , icon = o00oooO0Oo , themeit = II1I )
  if I1II1 == 'true' :
   oO0OOOO0 ( '--- Incluye Todos los Addons de Video: %s' % oooO . replace ( 'true' , Oo0OO ) . replace ( 'false' , O0OooOo0o ) , 'togglecache' , 'includeall' , icon = o00oooO0Oo , themeit = II1I )
   if 25 - 25: ooo + oO0OOoo0 / OO0ooOOO0OOO . oOI1Ii1I1 % OoOO000 * ooO00ooO000
   if 84 - 84: OO0ooOOO0OOO % oO0OOoo0 + i11iIiiIii
   if 28 - 28: oO00ooO0o0 + ooO00ooO000 * ii1Ii1I1Ii11i % OO0OOOOoo0OOO . i1111I1I % OoOO000
 I1i1Iiiii ( 'Accesorios' , 'mantenimiento' , 'misc' , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
 if view == "misc" or i1iiIIiiI111 == 'true' :
  if 16 - 16: i1111I1I - IIi11i1i1iI1 / oooO0 . Ii1Iiii1I1 + IIi11i1i1iI1
  oO0OOOO0 ( 'Fuerza Addons a Actualizar' , 'forceupdate' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Buscar Addons NO actualizados' , 'fixaddonupdate' , icon = o00oooO0Oo , themeit = II1I )
  if 19 - 19: ooO00ooO000 - oO00ooO0o0 . OoOO000
  if 60 - 60: Ii1Iiii1I1 + oO00ooO0o0
  if 9 - 9: OO0ooOOO0OOO * ii - IIi11i1i1iI1 + o0O00oO / ooO00ooO000 . ooO00ooO000
  oO0OOOO0 ( 'Cierra Kodi a la Fuerza' , 'forceclose' , icon = o00oooO0Oo , themeit = II1I )
  if 49 - 49: Ii1Iiii1I1
  oO0OOOO0 ( 'Ver Errores en el Log: %s' % ( iiI1IIIi ) , 'viewerrorlog' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Ver TODO el Archivo Log' , 'viewlog' , icon = o00oooO0Oo , themeit = II1I )
  if 25 - 25: ii - oooO0 . oooO0 * OO0OOOOoo0OOO
 I1i1Iiiii ( 'Utilidades' , 'mantenimiento' , 'utils' , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
 if view == "utils" or i1iiIIiiI111 == 'true' :
  if 81 - 81: O0o0OO0O00O + ooo
  if 98 - 98: oooO0
  if 95 - 95: OO0ooOOO0OOO / OO0ooOOO0OOO
  if 30 - 30: IiII111iI1ii1 + oO00ooO0o0 / oO00ooO0o0 % IiII111iI1ii1 . IiII111iI1ii1
  if 55 - 55: OO0ooOOO0OOO - i1111I1I + Ii1Iiii1I1 + O0o0OO0O00O % oO0OOoo0
  oO0OOOO0 ( 'Escanea Fuentes con links Rotos' , 'checksources' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Escanea Repositorios Rotos' , 'checkrepos' , icon = o00oooO0Oo , themeit = II1I )
  if 41 - 41: Ii11I1 - i1111I1I - oO0OOoo0
  oO0OOOO0 ( '--- Activa Todos los Addons de Video' , 'togglecache' , 'true' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( '--- Deshabilita Todos los Addons de Video' , 'togglecache' , 'false' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( wiz . sep ( ) , '' , themeit = II1I )
  oO0OOOO0 ( '[COLOR red][B]* Elimina Database - Destruye tu configuracion[/B][/COLOR]' , 'purgedb' , icon = o00oooO0Oo , themeit = ooOOoooooo )
 oO0OOOO0 ( '[COLOR red][B]* Fresh Start - RESTAURA KODI A CONFIG INICIAL[/B][/COLOR]' , 'freshstart' , icon = o00oooO0Oo , themeit = ooOOoooooo )
 if 8 - 8: ooO00ooO000 + o00oOOooOOo0o - oOI1Ii1I1 % oO00ooO0o0 % oOI1Ii1I1 * OO0OOOOoo0OOO
 if 9 - 9: oO00ooO0o0 - i11iIiiIii - ii1Ii1I1Ii11i * oO0OOoo0 + OO0ooOOO0OOO
 I1i1Iiiii ( 'Copia de respaldo' , 'mantenimiento' , 'backup' , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
 if view == "backup" or i1iiIIiiI111 == 'true' :
  oO0OOOO0 ( 'Borra archivo de BackUp' , 'clearbackup' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Carpeta del BackUp: [COLOR %s]%s[/COLOR]' % ( ooOOO00Ooo , oOOoo0Oo ) , 'settings' , 'Maintenance' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Hacer BackUp' , 'backupbuild' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Restaurar Copia de Seguridad' , 'restorezip' , icon = o00oooO0Oo , themeit = II1I )
  if 44 - 44: Ii1Iiii1I1
 I1i1Iiiii ( 'Configura El Buffer de tu Kodi' , 'mantenimiento' , 'tweaks' , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
 if view == "tweaks" or i1iiIIiiI111 == 'true' :
  if not iiI111I1iIiI == 'http://' and not iiI111I1iIiI == '' :
   I1i1Iiiii ( '[COLOR orange][B] Configura tu AvancedSettings[/B][/COLOR]' , 'advancedsetting' , icon = o00oooO0Oo , themeit = II1I )
  else :
   if os . path . exists ( ooOo ) :
    oO0OOOO0 ( '[B]Ver archivo actual AdvancedSettings.xml[/B]' , 'currentsettings' , icon = o00oooO0Oo , themeit = II1I )
    oO0OOOO0 ( '[COLOR red][B]Borrar el actual AdvancedSettings.xml[/B][/COLOR]' , 'removeadvanced' , icon = o00oooO0Oo , themeit = II1I )
   oO0OOOO0 ( '[B]Configuracion Rapida de AdvancedSettings.xml[/B]' , 'autoadvanced' , icon = o00oooO0Oo , themeit = II1I )
   if 52 - 52: IiII111iI1ii1 - oO00ooO0o0 + IiII111iI1ii1 % oOI1Ii1I1
   if 35 - 35: IIi11i1i1iI1
   if 42 - 42: o00oOOooOOo0o . oooO0 . Ii11I1 + o0O00oO + ii1Ii1I1Ii11i + oooO0
   if 31 - 31: O0o0OO0O00O . ii1Ii1I1Ii11i - OO0ooOOO0OOO . ii / ii
 oO00oOOoooO ( 'files' , 'viewType' )
 if 56 - 56: ooO00ooO000 / OO0OOOOoo0OOO / i11iIiiIii + ii - oO00ooO0o0 - i1111I1I
def Iii1iiIi1II ( view = None ) :
 Oo0OO = '[COLOR green]ON[/COLOR]' ; O0OooOo0o = '[COLOR red]OFF[/COLOR]'
 iiI11ii1I1 = 'true' if oooOOOOO == 'true' else 'false'
 Ooo0OOoOoO0 = 'true' if i1iiIII111ii == 'true' else 'false'
 oOo0OOoO0 = 'true' if i1iIIi1 == 'true' else 'false'
 IIo0Oo0oO0oOO00 = 'true' if ii11iIi1I == 'true' else 'false'
 OO0O00oOo = 'true' if i1iiIIiiI111 == 'true' else 'false'
 I1II1 = 'true' if iIii1 == 'true' else 'false'
 oooO = 'true' if oOOoO0 == 'true' else 'false'
 i1I1i111Ii = 'true' if O000oo0O == 'true' else 'false'
 if wiz . Grab_Log ( True ) == False : oooi1i1iI1iiiI = 0
 else : oooi1i1iI1iiiI = Ooo0oOooo0 ( wiz . Grab_Log ( True ) , True , True )
 if wiz . Grab_Log ( True , True ) == False : oOOOoo00 = 0
 else : oOOOoo00 = Ooo0oOooo0 ( wiz . Grab_Log ( True , True ) , True , True )
 iiIiIIIiiI = int ( oooi1i1iI1iiiI ) + int ( oOOOoo00 )
 iiI1IIIi = str ( iiIiIIIiiI ) + '[COLOR red] Errores encontrados [/COLOR]' if iiIiIIIiiI > 0 else 'No encontrados'
 II11IiIi11 = ': [COLOR greeen]No encontrados[/COLOR]' if not os . path . exists ( o0oO0 ) else ": [COLOR green]%s[/COLOR]" % wiz . convertSize ( os . path . getsize ( o0oO0 ) )
 if 14 - 14: oooO0
 if 19 - 19: ooO00ooO000 - oO00ooO0o0 . OO0OOOOoo0OOO / OO0OOOOoo0OOO % OO0ooOOO0OOO
 if 56 - 56: oooO0 . OoOO000 + oO00ooO0o0
 if 1 - 1: O0o0OO0O00O
 if 97 - 97: ii1Ii1I1Ii11i + O0o0OO0O00O + OoOO000 + i11iIiiIii
 if 77 - 77: oOI1Ii1I1 / ii
 if 46 - 46: oOI1Ii1I1 % IIi11i1i1iI1 . O0o0OO0O00O % O0o0OO0O00O + i11iIiiIii
 if 72 - 72: IIi11i1i1iI1 * oO0OOoo0 % OO0ooOOO0OOO / ooO00ooO000
 if 35 - 35: OO0ooOOO0OOO + Ii11I1 % IiII111iI1ii1 % i1111I1I + OO0OOOOoo0OOO
 if 17 - 17: Ii11I1
 if 21 - 21: oO00ooO0o0
 if 29 - 29: i1111I1I / Ii1Iiii1I1 / OO0ooOOO0OOO * ii1Ii1I1Ii11i
 if 10 - 10: o00oOOooOOo0o % ooo * ooo . i1111I1I / oO0OOoo0 % ii1Ii1I1Ii11i
 if 49 - 49: ooO00ooO000 / OO0OOOOoo0OOO + OoOO000 * oOI1Ii1I1
 if 28 - 28: OO0ooOOO0OOO + i11iIiiIii / i1111I1I % o0O00oO % oO00ooO0o0 - OoOO000
 if 54 - 54: Ii11I1 + Ii1Iiii1I1
 if 83 - 83: IiII111iI1ii1 - oooO0 + ii1Ii1I1Ii11i
 if 5 - 5: oO0OOoo0
 oOO0OOOo = wiz . getSize ( IiIi11iIIi1Ii )
 oo0o0000 = wiz . getSize ( iI1Ii11111iIi )
 iiI = wiz . getCacheSize ( )
 oOOO0o = oOO0OOOo + oo0o0000 + iiI
 O00oOOooo = [ 'Siempre' , 'A diario' , '2 Dias' , '3 Dias' , '5 Dias' , 'Semanal' ]
 if 46 - 46: ooo
 if 45 - 45: OO0ooOOO0OOO
 I1i1Iiiii ( 'Ver estado:' , 'mantenimiento' , 'clean' , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
 if view == "clean" or i1iiIIiiI111 == 'true' :
  oO0OOOO0 ( 'Limpieza Total: [COLOR gold][B]%s[/B][/COLOR]' % wiz . convertSize ( oOOO0o ) , 'fullclean' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Borra Cache: [COLOR gold][B]%s[/B][/COLOR]' % wiz . convertSize ( iiI ) , 'clearcache' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Borra Packages: [COLOR gold][B]%s[/B][/COLOR]' % wiz . convertSize ( oOO0OOOo ) , 'clearpackages' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Borra Thumbnails: [COLOR gold][B]%s[/B][/COLOR]' % wiz . convertSize ( oo0o0000 ) , 'clearthumb' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Borra iconos desactualizados' , 'oldThumbs' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Borra Crash Logs' , 'clearcrash' , icon = o00oooO0Oo , themeit = II1I )
  if 21 - 21: OO0OOOOoo0OOO . o00oOOooOOo0o . ii1Ii1I1Ii11i / oO00ooO0o0 / o00oOOooOOo0o
  if 17 - 17: ii1Ii1I1Ii11i / ii1Ii1I1Ii11i / i1111I1I
  if 1 - 1: Ii11I1 . i11iIiiIii % ii1Ii1I1Ii11i
 I1i1Iiiii ( 'Auto Limpieza' , 'mantenimiento' , 'Auto Clean' , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
 if view == "Auto Clean" or i1iiIIiiI111 == 'true' :
  oO0OOOO0 ( 'Auto Clean' , '' , fanart = O0oo0OO0 , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
  oO0OOOO0 ( 'Limpieza Automatica al inicio: %s' % iiI11ii1I1 . replace ( 'true' , Oo0OO ) . replace ( 'false' , O0OooOo0o ) , 'togglesetting' , 'autoclean' , icon = o00oooO0Oo , themeit = II1I )
 if iiI11ii1I1 == 'true' :
  oO0OOOO0 ( '--- Frecuencia Limpieza Auto: [B][COLOR gold]%s[/COLOR][/B]' % O00oOOooo [ iI111I11I1I1 ] , 'changefeq' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( '--- Borra Cache al inicio: %s' % Ooo0OOoOoO0 . replace ( 'true' , Oo0OO ) . replace ( 'false' , O0OooOo0o ) , 'togglesetting' , 'clearcache' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( '--- Borra Packages al inicio: %s' % oOo0OOoO0 . replace ( 'true' , Oo0OO ) . replace ( 'false' , O0OooOo0o ) , 'togglesetting' , 'clearpackages' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( '--- Borra Thumbnails al inicio: %s' % IIo0Oo0oO0oOO00 . replace ( 'true' , Oo0OO ) . replace ( 'false' , O0OooOo0o ) , 'togglesetting' , 'clearthumbs' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Clear Video Cache' , '' , fanart = O0oo0OO0 , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
  oO0OOOO0 ( 'Incluye Cache de Video en Borrado: %s' % I1II1 . replace ( 'true' , Oo0OO ) . replace ( 'false' , O0OooOo0o ) , 'togglecache' , 'includevideo' , icon = o00oooO0Oo , themeit = II1I )
  if I1II1 == 'true' :
   oO0OOOO0 ( '--- Incluye Todos los Addons de Video: %s' % oooO . replace ( 'true' , Oo0OO ) . replace ( 'false' , O0OooOo0o ) , 'togglecache' , 'includeall' , icon = o00oooO0Oo , themeit = II1I )
   if 82 - 82: IIi11i1i1iI1 + oO00ooO0o0 . IIi11i1i1iI1 % ooo / oO0OOoo0 . oO0OOoo0
   if 14 - 14: oOI1Ii1I1 . ii1Ii1I1Ii11i . i1111I1I + ii - ii1Ii1I1Ii11i + ooo
   if 9 - 9: oO0OOoo0
 I1i1Iiiii ( 'Accesorios' , 'maint' , 'misc' , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
 if view == "misc" or i1iiIIiiI111 == 'true' :
  if 59 - 59: oooO0 * Ii1Iiii1I1 . OoOO000
  if 56 - 56: oO0OOoo0 - O0o0OO0O00O % oooO0 - oOI1Ii1I1
  if 51 - 51: OoOO000 / OO0ooOOO0OOO * IIi11i1i1iI1 + IiII111iI1ii1 + oOI1Ii1I1
  if 98 - 98: IIi11i1i1iI1 * IiII111iI1ii1 * ii1Ii1I1Ii11i + OO0ooOOO0OOO % i11iIiiIii % OoOO000
  if 27 - 27: OoOO000
  if 79 - 79: oOI1Ii1I1 - i1111I1I + oOI1Ii1I1 . OO0OOOOoo0OOO
  oO0OOOO0 ( 'Cierra Kodi a la Fuerza' , 'forceclose' , icon = o00oooO0Oo , themeit = II1I )
  if 28 - 28: Ii11I1 - O0o0OO0O00O
  oO0OOOO0 ( 'Ver Errores en el Log: %s' % ( iiI1IIIi ) , 'viewerrorlog' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Ver TODO el Archivo Log' , 'viewlog' , icon = o00oooO0Oo , themeit = II1I )
  if 54 - 54: O0o0OO0O00O - OoOO000 % ii1Ii1I1Ii11i
 I1i1Iiiii ( 'Utilidades' , 'maint' , 'utils' , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
 if view == "utils" or i1iiIIiiI111 == 'true' :
  if 73 - 73: OoOO000 . o0O00oO + oooO0 - i1111I1I % i1111I1I . i1111I1I
  if 17 - 17: oO0OOoo0 - ii % oO0OOoo0 . ooo / i11iIiiIii % O0o0OO0O00O
  if 28 - 28: i1111I1I
  if 58 - 58: o0O00oO
  if 37 - 37: oO00ooO0o0 - IIi11i1i1iI1 / IiII111iI1ii1
  oO0OOOO0 ( 'Escanea Fuentes con links Rotos' , 'checksources' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Escanea Repositorios Rotos' , 'checkrepos' , icon = o00oooO0Oo , themeit = II1I )
  if 73 - 73: i11iIiiIii - ooo
  if 25 - 25: ii + ooo * IiII111iI1ii1
  if 92 - 92: oooO0 + i1111I1I + OoOO000 / oOI1Ii1I1 + o00oOOooOOo0o
  if 18 - 18: OO0ooOOO0OOO * o0O00oO . O0o0OO0O00O / IiII111iI1ii1 / i11iIiiIii
  oO0OOOO0 ( '[COLOR red][B]* Elimina Database - Destruye tu configuracion[/B][/COLOR]' , 'purgedb' , icon = o00oooO0Oo , themeit = ooOOoooooo )
  oO0OOOO0 ( '[COLOR red][B]* Fresh Start - RESTAURA KODI A CONFIG INICIAL[/B][/COLOR]' , 'freshstart' , icon = o00oooO0Oo , themeit = ooOOoooooo )
  if 21 - 21: OO0OOOOoo0OOO / IiII111iI1ii1 + oO0OOoo0 + ii
  if 91 - 91: i11iIiiIii / Ii11I1 + O0o0OO0O00O + OO0ooOOO0OOO * i11iIiiIii
 I1i1Iiiii ( 'Copia de Respaldo' , 'maint' , 'backup' , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
 if view == "backup" or i1iiIIiiI111 == 'true' :
  oO0OOOO0 ( 'Borra archivo de BackUp' , 'clearbackup' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Carpeta del BackUp: [COLOR %s]%s[/COLOR]' % ( ooOOO00Ooo , oOOoo0Oo ) , 'settings' , 'Maintenance' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Hacer BackUp' , 'backupbuild' , icon = o00oooO0Oo , themeit = II1I )
  oO0OOOO0 ( 'Restaurar Copia de Seguridad' , 'restorezip' , icon = o00oooO0Oo , themeit = II1I )
  if 66 - 66: IIi11i1i1iI1 % Ii11I1 - OoOO000 + i1111I1I * o00oOOooOOo0o . ooo
 I1i1Iiiii ( 'Configurar AdvancedSettings' , 'maint' , 'tweaks' , icon = o00oooO0Oo , themeit = IiIIIi1iIi )
 if view == "tweaks" or i1iiIIiiI111 == 'true' :
  if not iiI111I1iIiI == 'http://' and not iiI111I1iIiI == '' :
   I1i1Iiiii ( '[COLOR lime][B]- Config. Advanced Settings[/B][/COLOR]' , 'advancedsetting' , icon = o00oooO0Oo , themeit = II1I )
  else :
   if os . path . exists ( ooOo ) :
    oO0OOOO0 ( '[B]Ver archivo actual AdvancedSettings.xml[/B]' , 'currentsettings' , icon = o00oooO0Oo , themeit = II1I )
    oO0OOOO0 ( '[COLOR red][B]Borrar el actual AdvancedSettings.xml[/B][/COLOR]' , 'removeadvanced' , icon = o00oooO0Oo , themeit = II1I )
   oO0OOOO0 ( '[B]Configuracion Rapida de AdvancedSettings.xml[/B]' , 'autoadvanced' , icon = o00oooO0Oo , themeit = II1I )
   if 52 - 52: OO0ooOOO0OOO + OoOO000 . O0o0OO0O00O . IiII111iI1ii1 . ooO00ooO000
   if 97 - 97: oooO0 / O0o0OO0O00O
   if 71 - 71: Ii1Iiii1I1 / Ii11I1 . IiII111iI1ii1 % ii . o0O00oO
   if 41 - 41: Ii11I1 * Ii1Iiii1I1 / ii . ii1Ii1I1Ii11i
 oO00oOOoooO ( 'files' , 'viewType' )
 if 83 - 83: O0o0OO0O00O . OoOO000 / oO00ooO0o0 / ii1Ii1I1Ii11i - Ii1Iiii1I1
 if 100 - 100: ooO00ooO000
def II1i ( url = None ) :
 if not iiI111I1iIiI == 'http://' :
  if url == None :
   Ii1IIIIi1ii1I = wiz . workingURL ( iiI111I1iIiI )
   IiiIiI1Ii1i = conf . ADVANCEDFILE
  else :
   Ii1IIIIi1ii1I = wiz . workingURL ( url )
   IiiIiI1Ii1i = url
  oO0OOOO0 ( '[B]Configuracion Rapida de AdvancedSettings.xml[/B]' , 'autoadvanced' , icon = o00oooO0Oo , themeit = II1I )
  if os . path . exists ( ooOo ) :
   oO0OOOO0 ( '[B]Ver archivo actual AdvancedSettings.xml[/B]' , 'currentsettings' , icon = o00oooO0Oo , themeit = II1I )
   oO0OOOO0 ( '[COLOR red][B]Borrar el actual AdvancedSettings.xml[/B][/COLOR]' , 'removeadvanced' , icon = o00oooO0Oo , themeit = II1I )
  if Ii1IIIIi1ii1I == True :
   if O000OOo00oo == 'No' : oO0OOOO0 ( wiz . sep ( ) , '' , icon = o00oooO0Oo , themeit = II1I )
   i1iIi = wiz . openURL ( IiiIiI1Ii1i ) . replace ( '\n' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' )
   iiiii1II = re . compile ( 'name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"' ) . findall ( i1iIi )
   if len ( iiiii1II ) > 0 :
    for O0OOO0OOooo00 , I111iIi1 , url , oo00O00oO000o , OOo00OoO , iIi1 in iiiii1II :
     if I111iIi1 . lower ( ) == "yes" :
      I1i1Iiiii ( "[B]%s[/B]" % O0OOO0OOooo00 , 'advancedsetting' , url , description = iIi1 , icon = oo00O00oO000o , fanart = OOo00OoO , themeit = II1I )
     else :
      oO0OOOO0 ( O0OOO0OOooo00 , 'writeadvanced' , O0OOO0OOooo00 , url , description = iIi1 , icon = oo00O00oO000o , fanart = OOo00OoO , themeit = ooOOoooooo )
   else : wiz . log ( "[Advanced Settings] ERROR: Invalid Format." )
  else : wiz . log ( "[Advanced Settings] URL not working: %s" % Ii1IIIIi1ii1I )
 else : wiz . log ( "[Advanced Settings] not Enabled" )
 if 21 - 21: i1111I1I
def OoO00 ( name , url ) :
 Ii1IIIIi1ii1I = wiz . workingURL ( url )
 if Ii1IIIIi1ii1I == True :
  if os . path . exists ( ooOo ) : OO0Ooooo000Oo = II1 . yesno ( Oo0Ooo , "[COLOR %s]Quieres reemplazar tu actual archivo de AdvancedSettings con [COLOR %s]%s[/COLOR]?[/COLOR]" % ( ooOOO00Ooo , oo0OOo , name ) , yeslabel = "[B][COLOR gold]Reemplazar[/COLOR][/B]" , nolabel = "[B][COLOR red]Cancelar[/COLOR][/B]" )
  else : OO0Ooooo000Oo = II1 . yesno ( Oo0Ooo , "[COLOR %s]Te gustaria descargar e instalar [COLOR %s]%s[/COLOR]?[/COLOR]" % ( ooOOO00Ooo , oo0OOo , name ) , yeslabel = "[B][COLOR gold]Instalar[/COLOR][/B]" , nolabel = "[B][COLOR red]Cancelar[/COLOR][/B]" )
  if 97 - 97: oO0OOoo0 * IiII111iI1ii1 / oooO0 / IIi11i1i1iI1 % i1111I1I
  if OO0Ooooo000Oo == 1 :
   file = wiz . openURL ( url )
   O00oO0 = open ( ooOo , 'w' ) ;
   O00oO0 . write ( file )
   O00oO0 . close ( )
   II1 . ok ( Oo0Ooo , '[COLOR %s]AdvancedSettings.xml se ha escrito correctamente. Una vez que hagas clic en Aceptar, forzaras el cierre de kodi.[/COLOR]' % ooOOO00Ooo )
   wiz . killxbmc ( True )
  else : wiz . log ( "[Advanced Settings] instalacion canceleda" ) ; wiz . LogNotify ( '[COLOR %s]%s[/COLOR]' % ( oo0OOo , Oo0Ooo ) , "[COLOR %s]Escritura Cancelada![/COLOR]" % ooOOO00Ooo ) ; return
 else : wiz . log ( "[Advanced Settings] URL no funciona: %s" % Ii1IIIIi1ii1I ) ; wiz . LogNotify ( '[COLOR %s]%s[/COLOR]' % ( oo0OOo , Oo0Ooo ) , "[COLOR %s]URL No funciona[/COLOR]" % ooOOO00Ooo )
 if 97 - 97: o00oOOooOOo0o - IIi11i1i1iI1
def oo0o0O0Oooooo ( ) :
 O00oO0 = open ( ooOo )
 i11IIIiI1I = O00oO0 . read ( ) . replace ( '\t' , '    ' )
 wiz . TextBox ( Oo0Ooo , i11IIIiI1I )
 O00oO0 . close ( )
 if 69 - 69: OoOO000
def o0ooO ( ) :
 if os . path . exists ( ooOo ) :
  wiz . removeFile ( ooOo )
 else : LogNotify ( "[COLOR %s]%s[/COLOR]" % ( oo0OOo , Oo0Ooo ) , "[COLOR %s]AdvancedSettings.xml not found[/COLOR]" )
 if 74 - 74: OoOO000 * OO0OOOOoo0OOO - i11iIiiIii + o00oOOooOOo0o
def Iii ( ) :
 notify . autoConfig ( )
 if 19 - 19: i1111I1I % Ii1Iiii1I1 / i11iIiiIii / O0o0OO0O00O - ii
 if 37 - 37: ii1Ii1I1Ii11i / ii - i11iIiiIii
 if 18 - 18: O0o0OO0O00O . oooO0
 if 40 - 40: OoOO000 - ii - ooo
def iIiii ( ) :
 if Oo0oOOo < 17 :
  OOOO00OO0O0 = os . path . join ( i1i1II , wiz . latestDB ( 'Addons' ) )
  try :
   os . remove ( OOOO00OO0O0 )
  except Exception , i1I111Ii1i11 :
   wiz . log ( "Unable to remove %s, Purging DB" % OOOO00OO0O0 )
   wiz . purgeDb ( OOOO00OO0O0 )
 else :
  xbmc . log ( "Requested Addons.db be removed but doesnt work in Kod17" )
  if 81 - 81: ooO00ooO000
def oO0o00oOOooO0 ( ) :
 O00oOOooo = [ 'Cada inicio' , 'Cada dia' , 'cada dos dias' , 'Cada tres dias' , 'cada 5 dias' , 'Semanalmente' ]
 OOOoO000 = II1 . select ( "[COLOR %s]Con que frecuencia quieres que se ejecute?[/COLOR]" % ooOOO00Ooo , O00oOOooo )
 if not OOOoO000 == - 1 :
  wiz . setS ( 'autocleanfeq' , str ( OOOoO000 ) )
  wiz . LogNotify ( '[COLOR %s]Auto Limpieza[/COLOR]' % oo0OOo , '[COLOR %s]Establecida en %s[/COLOR]' % ( ooOOO00Ooo , O00oOOooo [ OOOoO000 ] ) )
  if 57 - 57: Ii1Iiii1I1
  if 54 - 54: oO00ooO0o0 + OO0OOOOoo0OOO + i11iIiiIii
  if 28 - 28: OO0OOOOoo0OOO
  if 70 - 70: ooo
  if 34 - 34: o00oOOooOOo0o % ooo
  if 3 - 3: Ii1Iiii1I1 / ii1Ii1I1Ii11i + ooo . OO0ooOOO0OOO . ooO00ooO000
  if 83 - 83: OO0OOOOoo0OOO + ii
  if 22 - 22: oO0OOoo0 % O0o0OO0O00O * ii - oOI1Ii1I1 / IIi11i1i1iI1
  if 86 - 86: ii . O0o0OO0O00O % o0O00oO / i1111I1I * O0o0OO0O00O / oOI1Ii1I1
  if 64 - 64: i11iIiiIii
  if 38 - 38: ooo / oooO0 - ooo . i1111I1I
  if 69 - 69: ii + IiII111iI1ii1
  if 97 - 97: ii1Ii1I1Ii11i - ooO00ooO000 / oO0OOoo0 . i11iIiiIii % OO0OOOOoo0OOO * OO0OOOOoo0OOO
  if 1 - 1: oooO0 % OO0ooOOO0OOO
  if 65 - 65: oooO0 + o0O00oO / ii1Ii1I1Ii11i
  if 83 - 83: oOI1Ii1I1 . O0o0OO0O00O - oO00ooO0o0
  if 65 - 65: IIi11i1i1iI1 / OO0ooOOO0OOO . ooo - Ii1Iiii1I1
  if 72 - 72: IIi11i1i1iI1 / ooo % O0o0OO0O00O % ii1Ii1I1Ii11i - i1111I1I % ii1Ii1I1Ii11i
  if 100 - 100: oO00ooO0o0 + i11iIiiIii
  if 71 - 71: i1111I1I / oOI1Ii1I1 / o00oOOooOOo0o % ii1Ii1I1Ii11i
  if 51 - 51: ooo * OoOO000 / Ii1Iiii1I1 . oO0OOoo0 % ii1Ii1I1Ii11i / oooO0
def ii1iii1I1I ( state ) :
 oO0Ooo0ooOO0 = [ 'includevideo' , 'includeall' , 'includebob' , 'includephoenix' , 'includespecto' , 'includegenesis' , 'includeexodus' , 'includeonechan' , 'includesalts' , 'includesaltslite' ]
 i1IIiIii1i = [ 'Include Video Addons' , 'Include All Addons' , 'Include Bob' , 'Include Phoenix' , 'Include Specto' , 'Include Genesis' , 'Include Exodus' , 'Include One Channel' , 'Include Salts' , 'Include Salts Lite HD' ]
 if state in [ 'true' , 'false' ] :
  for ooOOO0OooOo in oO0Ooo0ooOO0 :
   wiz . setS ( ooOOO0OooOo , state )
 else :
  if not state in [ 'includevideo' , 'includeall' ] and wiz . getS ( 'includeall' ) == 'true' :
   try :
    ooOOO0OooOo = i1IIiIii1i [ oO0Ooo0ooOO0 . index ( state ) ]
    II1 . ok ( Oo0Ooo , "[COLOR %s]Tendra que deshabilitar [COLOR %s]Incluir TODOS los Addons[/COLOR] a desactivar[/COLOR] [COLOR %s]%s[/COLOR]" % ( ooOOO00Ooo , oo0OOo , oo0OOo , ooOOO0OooOo ) )
   except :
    wiz . LogNotify ( "[COLOR %s]Toggle Cache[/COLOR]" % oo0OOo , "[COLOR %s]Invalid id: %s[/COLOR]" % ( ooOOO00Ooo , state ) )
  else :
   I1Ii = 'true' if wiz . getS ( state ) == 'false' else 'false'
   wiz . setS ( state , I1Ii )
   if 70 - 70: oO00ooO0o0 . ii - O0o0OO0O00O
def iII11I1Ii1 ( url ) :
 if 'watch?v=' in url :
  i11IIIiI1I , o0o0 = url . split ( '?' )
  oOo0oO = o0o0 . split ( '&' )
  for ooOOO0OooOo in oOo0oO :
   if ooOOO0OooOo . startswith ( 'v=' ) :
    url = ooOOO0OooOo [ 2 : ]
    break
   else : continue
 elif 'embed' in url or 'youtu.be' in url :
  i11IIIiI1I = url . split ( '/' )
  if len ( i11IIIiI1I [ - 1 ] ) > 5 :
   url = i11IIIiI1I [ - 1 ]
  elif len ( i11IIIiI1I [ - 2 ] ) > 5 :
   url = i11IIIiI1I [ - 2 ]
 wiz . log ( "YouTube URL: %s" % url )
 yt . PlayVideo ( url )
 if 5 - 5: ii1Ii1I1Ii11i - ii1Ii1I1Ii11i . oO00ooO0o0 + o0O00oO - ii1Ii1I1Ii11i . OO0OOOOoo0OOO
def IiIi1i1ii ( ) :
 iiIi = wiz . Grab_Log ( True )
 oOIi111 = wiz . Grab_Log ( True , True )
 oO0i1iI = 0 ; iioo0o0OoOOO = iiIi
 if not oOIi111 == False and not iiIi == False :
  oO0i1iI = II1 . select ( Oo0Ooo , [ "Ver %s" % iiIi . replace ( IIi1IiiiI1Ii , "" ) , "Ver %s" % oOIi111 . replace ( IIi1IiiiI1Ii , "" ) ] )
  if oO0i1iI == - 1 : wiz . LogNotify ( '[COLOR %s]Ver Log[/COLOR]' % oo0OOo , '[COLOR %s]Ver Log Cancelado![/COLOR]' % ooOOO00Ooo ) ; return
 elif iiIi == False and oOIi111 == False :
  wiz . LogNotify ( '[COLOR %s]Ver Log[/COLOR]' % oo0OOo , '[COLOR %s]Log File No Encontrado![/COLOR]' % ooOOO00Ooo )
  return
 elif not iiIi == False : oO0i1iI = 0
 elif not oOIi111 == False : oO0i1iI = 1
 if 88 - 88: O0o0OO0O00O
 iioo0o0OoOOO = iiIi if oO0i1iI == 0 else oOIi111
 iiI11I1i1i1iI = wiz . Grab_Log ( False ) if oO0i1iI == 0 else wiz . Grab_Log ( False , True )
 if 60 - 60: ii % oO00ooO0o0 + ii1Ii1I1Ii11i . OO0ooOOO0OOO * IIi11i1i1iI1
 wiz . TextBox ( "%s - %s" % ( Oo0Ooo , iioo0o0OoOOO ) , iiI11I1i1i1iI )
 if 93 - 93: ooO00ooO000
def Ooo0oOooo0 ( log = None , count = None , all = None ) :
 if log == None :
  iiIi = wiz . Grab_Log ( True )
  oOIi111 = wiz . Grab_Log ( True , True )
  if not oOIi111 == False and not iiIi == False :
   oO0i1iI = II1 . select ( Oo0Ooo , [ "Ver %s: %s error(es)" % ( iiIi . replace ( IIi1IiiiI1Ii , "" ) , Ooo0oOooo0 ( iiIi , True , True ) ) , "Ver %s: %s error(es)" % ( oOIi111 . replace ( IIi1IiiiI1Ii , "" ) , Ooo0oOooo0 ( oOIi111 , True , True ) ) ] )
   if oO0i1iI == - 1 : wiz . LogNotify ( '[COLOR %s]Ver Log[/COLOR]' % oo0OOo , '[COLOR %s]Ver Log Cancelado![/COLOR]' % ooOOO00Ooo ) ; return
  elif iiIi == False and oOIi111 == False :
   wiz . LogNotify ( '[COLOR %s]View Log[/COLOR]' % oo0OOo , '[COLOR %s]Log File No Encontrado![/COLOR]' % ooOOO00Ooo )
   return
  elif not iiIi == False : oO0i1iI = 0
  elif not oOIi111 == False : oO0i1iI = 1
  log = iiIi if oO0i1iI == 0 else oOIi111
 if log == False :
  if count == None :
   wiz . LogNotify ( "[COLOR %s]%s[/COLOR]" % ( oo0OOo , Oo0Ooo ) , "[COLOR %s]Log File No Encontrado[/COLOR]" % ooOOO00Ooo )
   return False
  else :
   return 0
 else :
  if os . path . exists ( log ) :
   O00oO0 = open ( log , mode = 'r' ) ; i11IIIiI1I = O00oO0 . read ( ) . replace ( '\n' , '' ) . replace ( '\r' , '' ) ; O00oO0 . close ( )
   iiiii1II = re . compile ( "-->Python callback/script devuelve el siguiente error<--(.+?)-->Fin del mensaje de error del script Python<--" ) . findall ( i11IIIiI1I )
   if not count == None :
    if all == None :
     i111I = 0
     for ooOOO0OooOo in iiiii1II :
      if OO0o in ooOOO0OooOo : i111I += 1
     return i111I
    else : return len ( iiiii1II )
   if len ( iiiii1II ) > 0 :
    i111I = 0 ; iiI11I1i1i1iI = ""
    for ooOOO0OooOo in iiiii1II :
     if all == None and not OO0o in ooOOO0OooOo : continue
     else :
      i111I += 1
      iiI11I1i1i1iI += "[COLOR red]Error Number %s[/COLOR]\n(PythonToCppException) : -->Python callback/script returned the following error<--%s-->Fin del mensaje de error del script Python<--\n\n" % ( i111I , ooOOO0OooOo . replace ( '                                          ' , '\n' ) . replace ( '\\\\' , '\\' ) . replace ( I1IiiI , '' ) )
    if i111I > 0 :
     wiz . TextBox ( Oo0Ooo , iiI11I1i1i1iI )
    else : wiz . LogNotify ( Oo0Ooo , "Sin errores en Log" )
   else : wiz . LogNotify ( Oo0Ooo , "Sin errores en Log" )
  else : wiz . LogNotify ( Oo0Ooo , "Log File no Encontrado" )
  if 57 - 57: oooO0 % i1111I1I - ii1Ii1I1Ii11i . oooO0 / oO00ooO0o0 % O0o0OO0O00O
OO = 10
I1iIi1iiIIiI = 92
oOoOOoOOooOO = 1
I11I = 2
iIIII1i = 3
o00oO0 = 4
i11I1II = 104
OO0 = 105
OOO0oOOo00O = 107
OO0oIII111i11IiI = 7
O0000 = 110
ooO00O0O0 = 100
iII1I1 = 108
if 85 - 85: O0o0OO0O00O * oOI1Ii1I1
def ii1iii11i1 ( default = None ) :
 class ii1iii11i1 ( xbmcgui . WindowXMLDialog ) :
  def __init__ ( self , * args , ** kwargs ) :
   self . default = kwargs [ 'default' ]
   if 4 - 4: ooo . ooo % IiII111iI1ii1 % oO0OOoo0 / oO0OOoo0
  def onInit ( self ) :
   self . title = 101
   self . msg = 102
   self . scrollbar = 103
   self . upload = 201
   self . kodi = 202
   self . kodiold = 203
   self . wizard = 204
   self . okbutton = 205
   O00oO0 = open ( self . default , 'r' )
   self . logmsg = O00oO0 . read ( )
   O00oO0 . close ( )
   self . titlemsg = "%s: %s" % ( Oo0Ooo , self . default . replace ( IIi1IiiiI1Ii , '' ) . replace ( IiI , '' ) )
   self . showdialog ( )
   if 29 - 29: oO00ooO0o0 * OO0ooOOO0OOO * IiII111iI1ii1 / i11iIiiIii
  def showdialog ( self ) :
   self . getControl ( self . title ) . setLabel ( self . titlemsg )
   self . getControl ( self . msg ) . setText ( wiz . highlightText ( self . logmsg ) )
   self . setFocusId ( self . scrollbar )
   if 26 - 26: ooo % o00oOOooOOo0o % OO0OOOOoo0OOO % oO0OOoo0
  def onClick ( self , controlId ) :
   if controlId == self . okbutton : self . close ( )
   elif controlId == self . upload : self . close ( ) ; uploadLog . Main ( )
   elif controlId == self . kodi :
    O0oo0ooOOOO = wiz . Grab_Log ( False )
    Ii1ii = wiz . Grab_Log ( True )
    if O0oo0ooOOOO == False :
     self . titlemsg = "%s: Ver Error Log" % Oo0Ooo
     self . getControl ( self . msg ) . setText ( "Log File No Existe!" )
    else :
     self . titlemsg = "%s: %s" % ( Oo0Ooo , Ii1ii . replace ( IIi1IiiiI1Ii , '' ) )
     self . getControl ( self . title ) . setLabel ( self . titlemsg )
     self . getControl ( self . msg ) . setText ( wiz . highlightText ( O0oo0ooOOOO ) )
     self . setFocusId ( self . scrollbar )
   elif controlId == self . kodiold :
    O0oo0ooOOOO = wiz . Grab_Log ( False , True )
    Ii1ii = wiz . Grab_Log ( True , True )
    if O0oo0ooOOOO == False :
     self . titlemsg = "%s: Ver Error Log" % Oo0Ooo
     self . getControl ( self . msg ) . setText ( "Log File No Existe!" )
    else :
     self . titlemsg = "%s: %s" % ( Oo0Ooo , Ii1ii . replace ( IIi1IiiiI1Ii , '' ) )
     self . getControl ( self . title ) . setLabel ( self . titlemsg )
     self . getControl ( self . msg ) . setText ( wiz . highlightText ( O0oo0ooOOOO ) )
     self . setFocusId ( self . scrollbar )
   elif controlId == self . wizard :
    O0oo0ooOOOO = wiz . Grab_Log ( False , False , True )
    Ii1ii = wiz . Grab_Log ( True , False , True )
    if O0oo0ooOOOO == False :
     self . titlemsg = "%s: Ver Error Log" % Oo0Ooo
     self . getControl ( self . msg ) . setText ( "Log File No Existe!" )
    else :
     self . titlemsg = "%s: %s" % ( Oo0Ooo , Ii1ii . replace ( IiI , '' ) )
     self . getControl ( self . title ) . setLabel ( self . titlemsg )
     self . getControl ( self . msg ) . setText ( wiz . highlightText ( O0oo0ooOOOO ) )
     self . setFocusId ( self . scrollbar )
     if 33 - 33: o00oOOooOOo0o
  def onAction ( self , action ) :
   if action == OO : self . close ( )
   elif action == I1iIi1iiIIiI : self . close ( )
 if default == None : default = wiz . Grab_Log ( True )
 OOO0ooo = ii1iii11i1 ( "LogViewer.xml" , O0O0OO0O0O0 . getAddonInfo ( 'path' ) , 'DefaultSkin' , default = default )
 OOO0ooo . doModal ( )
 del OOO0ooo
 if 7 - 7: oOI1Ii1I1 + Ii11I1 . oooO0 / oO00ooO0o0
 if 22 - 22: OO0ooOOO0OOO - OO0ooOOO0OOO % ii1Ii1I1Ii11i . o00oOOooOOo0o + OO0OOOOoo0OOO
 if 63 - 63: oooO0 % o00oOOooOOo0o * oOI1Ii1I1 + o00oOOooOOo0o / oO00ooO0o0 % O0o0OO0O00O
def iiI1i1Iii111 ( addon , name = None , over = False ) :
 if addon == 'all' :
  if II1 . yesno ( Oo0Ooo , '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder?[/COLOR]' % ( ooOOO00Ooo , oo0OOo ) , yeslabel = '[B][COLOR gold]Remove Data[/COLOR][/B]' , nolabel = '[B][COLOR red]Don\'t Remove[/COLOR][/B]' ) :
   wiz . cleanHouse ( Oo0O )
  else : wiz . LogNotify ( '[COLOR %s]Remove Addon Data[/COLOR]' % oo0OOo , '[COLOR %s]Cancelled![/COLOR]' % ooOOO00Ooo )
 elif addon == 'uninstalled' :
  if II1 . yesno ( Oo0Ooo , '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] addon data stored in you Userdata folder for uninstalled addons?[/COLOR]' % ( ooOOO00Ooo , oo0OOo ) , yeslabel = '[B][COLOR gold]Remove Data[/COLOR][/B]' , nolabel = '[B][COLOR red]Don\'t Remove[/COLOR][/B]' ) :
   i111I11i = 0
   for ii1 in glob . glob ( os . path . join ( Oo0O , '*' ) ) :
    OoOO = ii1 . replace ( Oo0O , '' ) . replace ( '\\' , '' ) . replace ( '/' , '' )
    if OoOO in OOO00O : pass
    elif os . path . exists ( os . path . join ( oO00oOo , OoOO ) ) : pass
    else : wiz . cleanHouse ( ii1 ) ; i111I11i += 1 ; wiz . log ( ii1 ) ; shutil . rmtree ( ii1 )
   wiz . LogNotify ( '[COLOR %s]Clean up Uninstalled[/COLOR]' % oo0OOo , '[COLOR %s]%s Folders(s) Removed[/COLOR]' % ( ooOOO00Ooo , i111I11i ) )
  else : wiz . LogNotify ( '[COLOR %s]Remove Addon Data[/COLOR]' % oo0OOo , '[COLOR %s]Cancelled![/COLOR]' % ooOOO00Ooo )
 elif addon == 'empty' :
  if II1 . yesno ( Oo0Ooo , '[COLOR %s]Would you like to remove [COLOR %s]ALL[/COLOR] empty addon data folders in you Userdata folder?[/COLOR]' % ( ooOOO00Ooo , oo0OOo ) , yeslabel = '[B][COLOR gold]Remove Data[/COLOR][/B]' , nolabel = '[B][COLOR red]Don\'t Remove[/COLOR][/B]' ) :
   i111I11i = wiz . emptyfolder ( Oo0O )
   wiz . LogNotify ( '[COLOR %s]Remove Empty Folders[/COLOR]' % oo0OOo , '[COLOR %s]%s Folders(s) Removed[/COLOR]' % ( ooOOO00Ooo , i111I11i ) )
  else : wiz . LogNotify ( '[COLOR %s]Remove Empty Folders[/COLOR]' % oo0OOo , '[COLOR %s]Cancelled![/COLOR]' % ooOOO00Ooo )
 else :
  iIII1I1i1i = os . path . join ( OOOo0 , 'addon_data' , addon )
  if addon in OOO00O :
   wiz . LogNotify ( "[COLOR %s]Protected Plugin[/COLOR]" % oo0OOo , "[COLOR %s]Not allowed to remove Addon_Data[/COLOR]" % ooOOO00Ooo )
  elif os . path . exists ( iIII1I1i1i ) :
   if II1 . yesno ( Oo0Ooo , '[COLOR %s]Would you also like to remove the addon data for:[/COLOR]' % ooOOO00Ooo , '[COLOR %s]%s[/COLOR]' % ( oo0OOo , addon ) , yeslabel = '[B][COLOR gold]Remove Data[/COLOR][/B]' , nolabel = '[B][COLOR red]Don\'t Remove[/COLOR][/B]' ) :
    wiz . cleanHouse ( iIII1I1i1i )
    try :
     shutil . rmtree ( iIII1I1i1i )
    except :
     wiz . log ( "Error deleting: %s" % iIII1I1i1i )
   else :
    wiz . log ( 'Addon data for %s was not removed' % addon )
 wiz . refresh ( )
 if 79 - 79: oO0OOoo0 . ooO00ooO000
def IIiI1I1 ( type ) :
 if type == 'build' :
  i111I = I11I1IIiiII1 ( 'restore' )
  if i111I == False : wiz . LogNotify ( "[COLOR %s]%s[/COLOR]" % ( oo0OOo , Oo0Ooo ) , "[COLOR %s]Local Restore Cancelado[/COLOR]" % ooOOO00Ooo ) ; return
 if not wiz . currSkin ( ) in [ 'skin.confluence' , 'skin.estuary' ] :
  wiz . skinToDefault ( )
 wiz . restoreLocal ( type )
 if 31 - 31: oooO0 * OO0OOOOoo0OOO + ii - O0o0OO0O00O / ii
def I111IIiii1Ii ( type ) :
 if type == 'build' :
  i111I = I11I1IIiiII1 ( 'restore' )
  if i111I == False : wiz . LogNotify ( "[COLOR %s]%s[/COLOR]" % ( oo0OOo , Oo0Ooo ) , "[COLOR %s]External Restore Cancelled[/COLOR]" % ooOOO00Ooo ) ; return
 wiz . restoreExternal ( type )
 if 13 - 13: OO0OOOOoo0OOO . oooO0 * OO0OOOOoo0OOO + oooO0
 if 59 - 59: oooO0 + i11iIiiIii + Ii11I1 / i1111I1I
 if 44 - 44: i1111I1I . o0O00oO * oooO0 + ii - O0o0OO0O00O - ooo
def I1iii ( name ) :
 if wiz . workingURL ( OOoOO0oo0ooO ) == True :
  oOO0OO0O = wiz . checkBuild ( name , 'preview' )
  if oOO0OO0O and not oOO0OO0O == 'http://' : iII11I1Ii1 ( oOO0OO0O )
  else : wiz . log ( "[%s]Unable to find url for video preview" % name )
 else : wiz . log ( "Build text file not working: %s" % WORKINGURL )
 if 78 - 78: oO0OOoo0 / Ii1Iiii1I1 % o0O00oO
def oO00OoOO ( plugin ) :
 I11IIiIiI = os . path . join ( oO00oOo , plugin , 'addon.xml' )
 if os . path . exists ( I11IIiIiI ) :
  iIIIi1i1I11i = open ( I11IIiIiI , mode = 'r' ) ; i1iIi = iIIIi1i1I11i . read ( ) ; iIIIi1i1I11i . close ( ) ;
  iiiii1II = wiz . parseDOM ( i1iIi , 'import' , ret = 'addon' )
  oOO0OO0OO = [ ]
  for oOOoooO in iiiii1II :
   if not 'xbmc.python' in oOOoooO :
    oOO0OO0OO . append ( oOOoooO )
  return oOO0OO0OO
 return [ ]
 if 22 - 22: i1111I1I + IIi11i1i1iI1
 if 24 - 24: o0O00oO % Ii11I1 + O0o0OO0O00O . i11iIiiIii . IiII111iI1ii1
 if 17 - 17: IiII111iI1ii1 . Ii1Iiii1I1 . OO0ooOOO0OOO / IiII111iI1ii1
def oOooO00o0O ( do ) :
 if do == 'import' :
  OOo0 = os . path . join ( IiI , 'temp' )
  if not os . path . exists ( OOo0 ) : os . makedirs ( OOo0 )
  iIIIi1i1I11i = II1 . browse ( 1 , '[COLOR %s]Select the location of the SaveData.zip[/COLOR]' % ooOOO00Ooo , 'files' , '.zip' , False , False , I1IiiI )
  if not iIIIi1i1I11i . endswith ( '.zip' ) :
   wiz . LogNotify ( "[COLOR %s]%s[/COLOR]" % ( oo0OOo , Oo0Ooo ) , "[COLOR %s]Import Data Error![/COLOR]" % ( ooOOO00Ooo ) )
   return
  iiIii1IIi = os . path . join ( oOOoo0Oo , 'SaveData.zip' )
  ii1IiIiI1 = xbmcvfs . copy ( iIIIi1i1I11i , iiIii1IIi )
  wiz . log ( "%s" % str ( ii1IiIiI1 ) )
  extract . all ( xbmc . translatePath ( iiIii1IIi ) , OOo0 )
  OOOoOo00O = os . path . join ( OOo0 , 'trakt' )
  O0ooOo0o0Oo = os . path . join ( OOo0 , 'login' )
  OooO0oOo = os . path . join ( OOo0 , 'debrid' )
  i111I = 0
  if os . path . exists ( OOOoOo00O ) :
   i111I += 1
   oOOo00O0OOOo = os . listdir ( OOOoOo00O )
   if not os . path . exists ( traktit . TRAKTFOLD ) : os . makedirs ( traktit . TRAKTFOLD )
   for ooOOO0OooOo in oOOo00O0OOOo :
    i11I1I1iiI = os . path . join ( traktit . TRAKTFOLD , ooOOO0OooOo )
    I1i1iii1Ii = os . path . join ( OOOoOo00O , ooOOO0OooOo )
    if os . path . exists ( i11I1I1iiI ) :
     if not II1 . yesno ( Oo0Ooo , "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % ( ooOOO00Ooo , oo0OOo , ooOOO0OooOo ) , yeslabel = "[B][COLOR gold]Yes Replace[/COLOR][/B]" , nolabel = "[B][COLOR red]No Skip[/COLOR][/B]" ) : continue
     else : os . remove ( i11I1I1iiI )
    shutil . copy ( I1i1iii1Ii , i11I1I1iiI )
   traktit . importlist ( 'all' )
   traktit . traktIt ( 'restore' , 'all' )
  if os . path . exists ( O0ooOo0o0Oo ) :
   i111I += 1
   oOOo00O0OOOo = os . listdir ( O0ooOo0o0Oo )
   if not os . path . exists ( loginit . LOGINFOLD ) : os . makedirs ( loginit . LOGINFOLD )
   for ooOOO0OooOo in oOOo00O0OOOo :
    i11I1I1iiI = os . path . join ( loginit . LOGINFOLD , ooOOO0OooOo )
    I1i1iii1Ii = os . path . join ( O0ooOo0o0Oo , ooOOO0OooOo )
    if os . path . exists ( i11I1I1iiI ) :
     if not II1 . yesno ( Oo0Ooo , "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % ( ooOOO00Ooo , oo0OOo , ooOOO0OooOo ) , yeslabel = "[B][COLOR gold]Yes Replace[/COLOR][/B]" , nolabel = "[B][COLOR red]No Skip[/COLOR][/B]" ) : continue
     else : os . remove ( i11I1I1iiI )
    shutil . copy ( I1i1iii1Ii , i11I1I1iiI )
   loginit . importlist ( 'all' )
   loginit . loginIt ( 'restore' , 'all' )
  if os . path . exists ( OooO0oOo ) :
   i111I += 1
   oOOo00O0OOOo = os . listdir ( OooO0oOo )
   if not os . path . exists ( debridit . REALFOLD ) : os . makedirs ( debridit . REALFOLD )
   for ooOOO0OooOo in oOOo00O0OOOo :
    i11I1I1iiI = os . path . join ( debridit . REALFOLD , ooOOO0OooOo )
    I1i1iii1Ii = os . path . join ( OooO0oOo , ooOOO0OooOo )
    if os . path . exists ( i11I1I1iiI ) :
     if not II1 . yesno ( Oo0Ooo , "[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?" % ( ooOOO00Ooo , oo0OOo , ooOOO0OooOo ) , yeslabel = "[B][COLOR gold]Yes Replace[/COLOR][/B]" , nolabel = "[B][COLOR red]No Skip[/COLOR][/B]" ) : continue
     else : os . remove ( i11I1I1iiI )
    shutil . copy ( I1i1iii1Ii , i11I1I1iiI )
   debridit . importlist ( 'all' )
   debridit . debridIt ( 'restore' , 'all' )
  wiz . cleanHouse ( OOo0 )
  wiz . removeFolder ( OOo0 )
  os . remove ( iiIii1IIi )
  if i111I == 0 : wiz . LogNotify ( "[COLOR %s]%s[/COLOR]" % ( oo0OOo , Oo0Ooo ) , "[COLOR %s]Save Data Import Failed[/COLOR]" % ooOOO00Ooo )
  else : wiz . LogNotify ( "[COLOR %s]%s[/COLOR]" % ( oo0OOo , Oo0Ooo ) , "[COLOR %s]Save Data Import Complete[/COLOR]" % ooOOO00Ooo )
 elif do == 'export' :
  iI = xbmc . translatePath ( oOOoo0Oo )
  dir = [ traktit . TRAKTFOLD , debridit . REALFOLD , loginit . LOGINFOLD ]
  traktit . traktIt ( 'update' , 'all' )
  loginit . loginIt ( 'update' , 'all' )
  debridit . debridIt ( 'update' , 'all' )
  iIIIi1i1I11i = II1 . browse ( 3 , '[COLOR %s]Seleccione donde quiere guardar sus datos zip?[/COLOR]' % ooOOO00Ooo , 'files' , '' , False , True , I1IiiI )
  iIIIi1i1I11i = xbmc . translatePath ( iIIIi1i1I11i )
  O0O00OOo = os . path . join ( iI , 'SaveData.zip' )
  OoOOo = zipfile . ZipFile ( O0O00OOo , mode = 'w' )
  for iii1 in dir :
   if os . path . exists ( iii1 ) :
    oOOo00O0OOOo = os . listdir ( iii1 )
    for file in oOOo00O0OOOo :
     OoOOo . write ( os . path . join ( iii1 , file ) , os . path . join ( iii1 , file ) . replace ( IiI , '' ) , zipfile . ZIP_DEFLATED )
  OoOOo . close ( )
  if iIIIi1i1I11i == iI :
   II1 . ok ( Oo0Ooo , "[COLOR %s]Save data has been backed up to:[/COLOR]" % ( ooOOO00Ooo ) , "[COLOR %s]%s[/COLOR]" % ( oo0OOo , O0O00OOo ) )
  else :
   try :
    xbmcvfs . copy ( O0O00OOo , os . path . join ( iIIIi1i1I11i , 'SaveData.zip' ) )
    II1 . ok ( Oo0Ooo , "[COLOR %s]Save data has been backed up to:[/COLOR]" % ( ooOOO00Ooo ) , "[COLOR %s]%s[/COLOR]" % ( oo0OOo , os . path . join ( iIIIi1i1I11i , 'SaveData.zip' ) ) )
   except :
    II1 . ok ( Oo0Ooo , "[COLOR %s]Save data has been backed up to:[/COLOR]" % ( ooOOO00Ooo ) , "[COLOR %s]%s[/COLOR]" % ( oo0OOo , O0O00OOo ) )
    if 78 - 78: IiII111iI1ii1 + i1111I1I - OoOO000
    if 10 - 10: o00oOOooOOo0o % oooO0
    if 97 - 97: ii - o00oOOooOOo0o
def I11I1IIiiII1 ( install = None , over = False ) :
 if 58 - 58: IIi11i1i1iI1 + OoOO000
 if 30 - 30: OO0ooOOO0OOO % O0o0OO0O00O * ii1Ii1I1Ii11i - IiII111iI1ii1 * oO0OOoo0 % OO0ooOOO0OOO
 if 46 - 46: i11iIiiIii - OoOO000 . OO0OOOOoo0OOO
 if 100 - 100: oooO0 / oOI1Ii1I1 * O0o0OO0O00O . OoOO000 / ii1Ii1I1Ii11i
 if 83 - 83: o00oOOooOOo0o
 if 48 - 48: Ii1Iiii1I1 * ii1Ii1I1Ii11i * o00oOOooOOo0o
 if I11iii1Ii == 'true' :
  loginit . autoUpdate ( 'all' )
  wiz . setS ( 'loginlastsave' , str ( oO0 ) )
 if over == True : i1iiiIii11 = 1
 elif install == 'restore' : i1iiiIii11 = II1 . yesno ( Oo0Ooo , "[COLOR %s]Restablecer la configuracion de Kodi a valores iniciales" % ooOOO00Ooo , "" , "ANTES de restaurar su copia de seguridad?[/COLOR]" , nolabel = '[B][COLOR red]No, Cancelar[/COLOR][/B]' , yeslabel = '[B][COLOR gold]Continuar[/COLOR][/B]' )
 elif install : i1iiiIii11 = II1 . yesno ( Oo0Ooo , "[COLOR %s]Restablecer la configuracion de Kodi" % ooOOO00Ooo , "a valores iniciales" , "Antes de instalar [COLOR %s]%s[/COLOR]?" % ( oo0OOo , install ) , nolabel = '[B][COLOR red]No, Cancelar[/COLOR][/B]' , yeslabel = '[B][COLOR gold]Continuar[/COLOR][/B]' )
 else : i1iiiIii11 = II1 . yesno ( Oo0Ooo , "[COLOR %s]Restablecer la configuracion de Kodi" % ooOOO00Ooo , "a valores iniciales?[/COLOR]" , nolabel = '[B][COLOR red]No, Cancelar[/COLOR][/B]' , yeslabel = '[B][COLOR gold]Continuar[/COLOR][/B]' )
 if i1iiiIii11 :
  if not wiz . currSkin ( ) in [ 'skin.confluence' , 'skin.estuary' ] :
   OOoOOO000O0 = 'skin.confluence' if Oo0oOOo < 17 else 'skin.estuary'
   if 92 - 92: IiII111iI1ii1 / OoOO000
   skinSwitch . swapSkins ( OOoOOO000O0 )
   i111I = 0
   xbmc . sleep ( 1000 )
   while not xbmc . getCondVisibility ( "Window.isVisible(yesnodialog)" ) and i111I < 150 :
    i111I += 1
    xbmc . sleep ( 200 )
    wiz . ebi ( 'SendAction(Select)' )
   if xbmc . getCondVisibility ( "Window.isVisible(yesnodialog)" ) :
    wiz . ebi ( 'SendClick(11)' )
   else : wiz . LogNotify ( "[COLOR %s]%s[/COLOR]" % ( oo0OOo , Oo0Ooo ) , '[COLOR %s]Fresh Install: Skin Swap Timed Out![/COLOR]' % ooOOO00Ooo ) ; return False
   xbmc . sleep ( 1000 )
  if not wiz . currSkin ( ) in [ 'skin.confluence' , 'skin.estuary' ] :
   wiz . LogNotify ( "[COLOR %s]%s[/COLOR]" % ( oo0OOo , Oo0Ooo ) , '[COLOR %s]Fresh Install: Skin Swap Failed![/COLOR]' % ooOOO00Ooo )
   return
  wiz . addonUpdates ( 'set' )
  oOO0o00O = os . path . abspath ( I1IiiI )
  O00ooooo00 . create ( Oo0Ooo , "[COLOR %s]Calculating files and folders" % ooOOO00Ooo , '' , 'Please Wait![/COLOR]' )
  oOoO = sum ( [ len ( oOOo00O0OOOo ) for IIIIiI1iiiIiii , ii1i1i , oOOo00O0OOOo in os . walk ( oOO0o00O ) ] ) ; II11iIII1i1I = 0
  O00ooooo00 . update ( 0 , "[COLOR %s]Gathering Excludes list." % ooOOO00Ooo )
  OOO00O . append ( 'My_Builds' )
  OOO00O . append ( 'archive_cache' )
  if 63 - 63: oO00ooO0o0 + o00oOOooOOo0o - Ii1Iiii1I1
  if 2 - 2: ooo
  if 97 - 97: OO0OOOOoo0OOO - ii
  if 79 - 79: o0O00oO % ooo % oO00ooO0o0
  if 29 - 29: ii . oooO0 % IiII111iI1ii1 - O0o0OO0O00O
  if 8 - 8: Ii11I1
  if 32 - 32: OO0OOOOoo0OOO / Ii1Iiii1I1
  if 45 - 45: IiII111iI1ii1 + ooO00ooO000 * i11iIiiIii / ii1Ii1I1Ii11i % i1111I1I * OoOO000
  if 17 - 17: OoOO000
  if 88 - 88: oO00ooO0o0 . OoOO000 % ii / ii1Ii1I1Ii11i
  if 89 - 89: Ii1Iiii1I1 / OO0OOOOoo0OOO
  if 14 - 14: ii1Ii1I1Ii11i . oooO0 * OO0ooOOO0OOO + Ii1Iiii1I1 - OO0ooOOO0OOO + ii1Ii1I1Ii11i
  if 18 - 18: OO0OOOOoo0OOO - oOI1Ii1I1 - oooO0 - oooO0
  if 54 - 54: oO00ooO0o0 + oooO0 / O0o0OO0O00O . oooO0 * o0O00oO
  if 1 - 1: o0O00oO * ooO00ooO000 . Ii11I1 / oO00ooO0o0 . IiII111iI1ii1 + oO00ooO0o0
  if 17 - 17: oO00ooO0o0 + ooO00ooO000 / oO0OOoo0 / O0o0OO0O00O * ii1Ii1I1Ii11i
  if 29 - 29: ooO00ooO000 % ii * OO0OOOOoo0OOO / Ii1Iiii1I1 - OO0OOOOoo0OOO
  if 19 - 19: i11iIiiIii
  if 54 - 54: Ii1Iiii1I1 . i1111I1I
  if 73 - 73: o0O00oO . oooO0
  if 32 - 32: o0O00oO * oooO0 % OO0ooOOO0OOO * oO0OOoo0 . OoOO000
  if 48 - 48: O0o0OO0O00O * O0o0OO0O00O
  if 13 - 13: oO0OOoo0 / i1111I1I + o0O00oO . oOI1Ii1I1 % OO0ooOOO0OOO
  if 48 - 48: oooO0 / i11iIiiIii - oOI1Ii1I1 * OO0OOOOoo0OOO / ii
  if 89 - 89: IIi11i1i1iI1 / oooO0 - Ii1Iiii1I1 / oO0OOoo0 . i11iIiiIii . oO0OOoo0
  if 48 - 48: OoOO000 + OoOO000 . o00oOOooOOo0o - OO0ooOOO0OOO
  if 63 - 63: OO0OOOOoo0OOO
  if wiz . getS ( 'pvrclient' ) == '' :
   for ooOOO0OooOo in OOO00O :
    if ooOOO0OooOo . startswith ( 'pvr' ) :
     wiz . setS ( 'pvrclient' , ooOOO0OooOo )
  O00ooooo00 . update ( 0 , "[COLOR %s]Clearing out files and folders:" % ooOOO00Ooo )
  Oo0 = wiz . latestDB ( 'Addons' )
  for OOo0Oo0OOo0 , i1i11I , oOOo00O0OOOo in os . walk ( oOO0o00O , topdown = True ) :
   i1i11I [ : ] = [ ii1i1i for ii1i1i in i1i11I if ii1i1i not in OOO00O ]
   for O0OOO0OOooo00 in oOOo00O0OOOo :
    II11iIII1i1I += 1
    iii1 = OOo0Oo0OOo0 . replace ( '/' , '\\' ) . split ( '\\' )
    i111I = len ( iii1 ) - 1
    if O0OOO0OOooo00 == 'sources.xml' and iii1 [ - 1 ] == 'userdata' and ooooooO0oo == 'true' : wiz . log ( "Guardar Fuentes: %s" % os . path . join ( OOo0Oo0OOo0 , O0OOO0OOooo00 ) , xbmc . LOGNOTICE )
    elif O0OOO0OOooo00 == 'favourites.xml' and iii1 [ - 1 ] == 'userdata' and IIIII == 'true' : wiz . log ( "Guardar Favoritos: %s" % os . path . join ( OOo0Oo0OOo0 , O0OOO0OOooo00 ) , xbmc . LOGNOTICE )
    elif O0OOO0OOooo00 == 'profiles.xml' and iii1 [ - 1 ] == 'userdata' and IIiiiiiiIi1I1 == 'true' : wiz . log ( "Guardar Perfil: %s" % os . path . join ( OOo0Oo0OOo0 , O0OOO0OOooo00 ) , xbmc . LOGNOTICE )
    elif O0OOO0OOooo00 == 'advancedsettings.xml' and iii1 [ - 1 ] == 'userdata' and I1IIIii == 'true' : wiz . log ( "Guardar AdvancedSettings: %s" % os . path . join ( OOo0Oo0OOo0 , O0OOO0OOooo00 ) , xbmc . LOGNOTICE )
    elif O0OOO0OOooo00 in oo0OOo0 : wiz . log ( "Guardar Log File: %s" % O0OOO0OOooo00 , xbmc . LOGNOTICE )
    elif O0OOO0OOooo00 . endswith ( '.db' ) :
     try :
      if O0OOO0OOooo00 == Oo0 and Oo0oOOo >= 17 : wiz . log ( "Ignorar %s on v%s" % ( O0OOO0OOooo00 , Oo0oOOo ) , xbmc . LOGNOTICE )
      else : os . remove ( os . path . join ( OOo0Oo0OOo0 , O0OOO0OOooo00 ) )
     except Exception , i1I111Ii1i11 :
      if not O0OOO0OOooo00 . startswith ( 'Textures13' ) :
       wiz . log ( 'Fallo al Borrar, Purging DB' , xbmc . LOGNOTICE )
       wiz . log ( "-> %s" % ( str ( i1I111Ii1i11 ) ) , xbmc . LOGNOTICE )
       wiz . purgeDb ( os . path . join ( OOo0Oo0OOo0 , O0OOO0OOooo00 ) )
    else :
     O00ooooo00 . update ( int ( wiz . percentage ( II11iIII1i1I , oOoO ) ) , '' , '[COLOR %s]File: [/COLOR][COLOR %s]%s[/COLOR]' % ( ooOOO00Ooo , oo0OOo , O0OOO0OOooo00 ) , '' )
     try : os . remove ( os . path . join ( OOo0Oo0OOo0 , O0OOO0OOooo00 ) )
     except Exception , i1I111Ii1i11 :
      wiz . log ( "Error removing %s" % os . path . join ( OOo0Oo0OOo0 , O0OOO0OOooo00 ) , xbmc . LOGNOTICE )
      wiz . log ( "-> / %s" % ( str ( i1I111Ii1i11 ) ) , xbmc . LOGNOTICE )
   if O00ooooo00 . iscanceled ( ) :
    O00ooooo00 . close ( )
    wiz . LogNotify ( "[COLOR %s]%s[/COLOR]" % ( oo0OOo , Oo0Ooo ) , "[COLOR %s]Fresh Start Cancelado[/COLOR]" % ooOOO00Ooo )
    return False
  for OOo0Oo0OOo0 , i1i11I , oOOo00O0OOOo in os . walk ( oOO0o00O , topdown = True ) :
   i1i11I [ : ] = [ ii1i1i for ii1i1i in i1i11I if ii1i1i not in OOO00O ]
   for O0OOO0OOooo00 in i1i11I :
    O00ooooo00 . update ( 100 , '' , 'Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]' % ( oo0OOo , O0OOO0OOooo00 ) , '' )
    if O0OOO0OOooo00 not in [ "Database" , "userdata" , "temp" , "addons" , "addon_data" ] :
     shutil . rmtree ( os . path . join ( OOo0Oo0OOo0 , O0OOO0OOooo00 ) , ignore_errors = True , onerror = None )
   if O00ooooo00 . iscanceled ( ) :
    O00ooooo00 . close ( )
    wiz . LogNotify ( "[COLOR %s]%s[/COLOR]" % ( oo0OOo , Oo0Ooo ) , "[COLOR %s]Fresh Start Cancelado[/COLOR]" % ooOOO00Ooo )
    return False
  O00ooooo00 . close ( )
  wiz . clearS ( 'build' )
  if over == True :
   return True
  elif install == 'restore' :
   return True
  elif install :
   buildWizard ( install , 'normal' , over = True )
  else :
   if I11 == 1 : iiIiIi1 = 1
   elif I11 == 2 : iiIiIi1 = 0
   else : iiIiIi1 = II1 . yesno ( Oo0Ooo , "[COLOR %s]Quieres [COLOR %s]Forzar salida[/COLOR]de kodi o [COLOR %s]Recargar Pefil[/COLOR]?[/COLOR]" % ( ooOOO00Ooo , oo0OOo , oo0OOo ) , yeslabel = "[B][COLOR red]Recargar Pefil[/COLOR][/B]" , nolabel = "[B][COLOR gold]Forzar salida[/COLOR][/B]" )
   if iiIiIi1 == 1 : wiz . reloadFix ( 'fresh' )
   else : wiz . addonUpdates ( 'reset' ) ; wiz . killxbmc ( True )
 else :
  if not install == 'restore' :
   wiz . LogNotify ( "[COLOR %s]%s[/COLOR]" % ( oo0OOo , Oo0Ooo ) , '[COLOR %s]Fresh Install: Cancelado![/COLOR]' % ooOOO00Ooo )
   wiz . refresh ( )
   if 78 - 78: ii1Ii1I1Ii11i % oOI1Ii1I1
def IIIiIiI ( ) :
 if II1 . yesno ( Oo0Ooo , '[COLOR %s]Deseas Borrar cache?[/COLOR]' % ooOOO00Ooo , nolabel = '[B][COLOR red]No, Cancelar[/COLOR][/B]' , yeslabel = '[B][COLOR gold]Borrar Cache[/COLOR][/B]' ) :
  wiz . clearCache ( )
  if 7 - 7: ooo . o0O00oO / IiII111iI1ii1 . ii1Ii1I1Ii11i * i1111I1I - Ii1Iiii1I1
  if 37 - 37: o00oOOooOOo0o . o0O00oO / OoOO000 * O0o0OO0O00O
def III11iiii11i1 ( ) :
 if II1 . yesno ( Oo0Ooo , '[COLOR %s]Deseas borrar cache, packages y thumbnails?[/COLOR]' % ooOOO00Ooo , nolabel = '[B][COLOR red]Cancelar Proceso[/COLOR][/B]' , yeslabel = '[B][COLOR gold]Borrar TODO[/COLOR][/B]' ) :
  wiz . clearCache ( )
  wiz . clearPackages ( 'total' )
  ooOo0OoO ( 'total' )
  if 36 - 36: ooo - ii / ooO00ooO000
def ooOo0OoO ( type = None ) :
 iIIi1iI1I1IIi = wiz . latestDB ( 'Textures' )
 if not type == None : OO0Ooooo000Oo = 1
 else : OO0Ooooo000Oo = II1 . yesno ( Oo0Ooo , '[COLOR %s]Deseas borrar Thumbnails %s y carpetas de iconos?' % ( ooOOO00Ooo , iIIi1iI1I1IIi ) , "Se regeneraran al siguiente inicio[/COLOR]" , nolabel = '[B][COLOR red]No borrar[/COLOR][/B]' , yeslabel = '[B][COLOR gold]Borrar Thumbs[/COLOR][/B]' )
 if OO0Ooooo000Oo == 1 :
  try : wiz . removeFile ( os . join ( i1i1II , iIIi1iI1I1IIi ) )
  except : wiz . log ( 'Fallo al borrar, Purging DB.' ) ; wiz . purgeDb ( iIIi1iI1I1IIi )
  wiz . removeFolder ( iI1Ii11111iIi )
  if 77 - 77: OO0ooOOO0OOO / oO00ooO0o0 + OO0ooOOO0OOO % oOI1Ii1I1 - oooO0 * oooO0
 else : wiz . log ( 'Borrar thumbnames cancelado' )
 wiz . redoThumbs ( )
 if 23 - 23: O0o0OO0O00O . Ii1Iiii1I1 % IiII111iI1ii1 - ii * oO00ooO0o0 . IIi11i1i1iI1
def I1iI ( ) :
 O0o00O0Oo0 = [ ] ; o0I11iII = [ ]
 for IiiIiI , iIIIIiiIii , oOOo00O0OOOo in os . walk ( I1IiiI ) :
  for O00oO0 in fnmatch . filter ( oOOo00O0OOOo , '*.db' ) :
   if O00oO0 != 'Thumbs.db' :
    ooO0oo = os . path . join ( IiiIiI , O00oO0 )
    O0o00O0Oo0 . append ( ooO0oo )
    dir = ooO0oo . replace ( '\\' , '/' ) . split ( '/' )
    o0I11iII . append ( '(%s) %s' % ( dir [ len ( dir ) - 2 ] , dir [ len ( dir ) - 1 ] ) )
 if Oo0oOOo >= 16 :
  OO0Ooooo000Oo = II1 . multiselect ( "[COLOR %s]Selecciona DB a eliminar[/COLOR]" % ooOOO00Ooo , o0I11iII )
  if OO0Ooooo000Oo == None : wiz . LogNotify ( "[COLOR %s]Elimina Database[/COLOR]" % oo0OOo , "[COLOR %s]Cancelado[/COLOR]" % ooOOO00Ooo )
  elif len ( OO0Ooooo000Oo ) == 0 : wiz . LogNotify ( "[COLOR %s]Elimina Database[/COLOR]" % oo0OOo , "[COLOR %s]Cancelado[/COLOR]" % ooOOO00Ooo )
  else :
   for ooO0oo0o0 in OO0Ooooo000Oo : wiz . purgeDb ( O0o00O0Oo0 [ ooO0oo0o0 ] )
 else :
  OO0Ooooo000Oo = II1 . select ( "[COLOR %s]Selecciona DB a eliminar[/COLOR]" % ooOOO00Ooo , o0I11iII )
  if OO0Ooooo000Oo == - 1 : wiz . LogNotify ( "[COLOR %s]Elimina Database[/COLOR]" % oo0OOo , "[COLOR %s]Cancelado[/COLOR]" % ooOOO00Ooo )
  else : wiz . purgeDb ( O0o00O0Oo0 [ ooO0oo0o0 ] )
  if 9 - 9: oooO0 + IiII111iI1ii1 / oooO0 . OO0OOOOoo0OOO * OO0ooOOO0OOO
  if 45 - 45: i11iIiiIii
  if 82 - 82: oO0OOoo0 + ooo
def I1i1Iiiii ( display , mode = None , name = None , url = None , menu = None , description = Oo0Ooo , overwrite = True , fanart = O0oo0OO0 , icon = I1i1iiI1 , themeit = None ) :
 i111i1iIiiIiI = sys . argv [ 0 ]
 if not mode == None : i111i1iIiiIiI += "?mode=%s" % urllib . quote_plus ( mode )
 if not name == None : i111i1iIiiIiI += "&name=" + urllib . quote_plus ( name )
 if not url == None : i111i1iIiiIiI += "&url=" + urllib . quote_plus ( url )
 ii1iIIiii1 = True
 if themeit : display = themeit % display
 ooOo0O0o0 = xbmcgui . ListItem ( display , iconImage = "DefaultFolder.png" , thumbnailImage = icon )
 ooOo0O0o0 . setInfo ( type = "Video" , infoLabels = { "Title" : display , "Plot" : description } )
 ooOo0O0o0 . setProperty ( "Fanart_Image" , fanart )
 if not menu == None : ooOo0O0o0 . addContextMenuItems ( menu , replaceItems = overwrite )
 ii1iIIiii1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = i111i1iIiiIiI , listitem = ooOo0O0o0 , isFolder = True )
 return ii1iIIiii1
 if 65 - 65: OO0ooOOO0OOO + OoOO000
def oO0OOOO0 ( display , mode = None , name = None , url = None , menu = None , description = Oo0Ooo , overwrite = True , fanart = O0oo0OO0 , icon = I1i1iiI1 , themeit = None ) :
 i111i1iIiiIiI = sys . argv [ 0 ]
 if not mode == None : i111i1iIiiIiI += "?mode=%s" % urllib . quote_plus ( mode )
 if not name == None : i111i1iIiiIiI += "&name=" + urllib . quote_plus ( name )
 if not url == None : i111i1iIiiIiI += "&url=" + urllib . quote_plus ( url )
 ii1iIIiii1 = True
 if themeit : display = themeit % display
 ooOo0O0o0 = xbmcgui . ListItem ( display , iconImage = "DefaultFolder.png" , thumbnailImage = icon )
 ooOo0O0o0 . setInfo ( type = "Video" , infoLabels = { "Title" : display , "Plot" : description } )
 ooOo0O0o0 . setProperty ( "Fanart_Image" , fanart )
 if not menu == None : ooOo0O0o0 . addContextMenuItems ( menu , replaceItems = overwrite )
 ii1iIIiii1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = i111i1iIiiIiI , listitem = ooOo0O0o0 , isFolder = False )
 return ii1iIIiii1
 if 32 - 32: ii - o0O00oO - i11iIiiIii * oOI1Ii1I1 / oO00ooO0o0 + ii
def ii1I1I111 ( ) :
 Ii1Ii = [ ]
 IIiii11iI = sys . argv [ 2 ]
 if len ( IIiii11iI ) >= 2 :
  i11i1Ii1 = sys . argv [ 2 ]
  o0oO0oo0000OO = i11i1Ii1 . replace ( '?' , '' )
  if ( i11i1Ii1 [ len ( i11i1Ii1 ) - 1 ] == '/' ) :
   i11i1Ii1 = i11i1Ii1 [ 0 : len ( i11i1Ii1 ) - 2 ]
  I1i1ii1IiIii = o0oO0oo0000OO . split ( '&' )
  Ii1Ii = { }
  for oOOO0O0Ooo in range ( len ( I1i1ii1IiIii ) ) :
   Ii = { }
   Ii = I1i1ii1IiIii [ oOOO0O0Ooo ] . split ( '=' )
   if ( len ( Ii ) ) == 2 :
    Ii1Ii [ Ii [ 0 ] ] = Ii [ 1 ]
    if 42 - 42: oO0OOoo0 * o00oOOooOOo0o . ooo * oooO0 + o0O00oO
  return Ii1Ii
  if 25 - 25: i1111I1I . oooO0 + OO0OOOOoo0OOO
  if 75 - 75: ooo - oOI1Ii1I1 % O0o0OO0O00O + i11iIiiIii
  if 100 - 100: i1111I1I + oOI1Ii1I1 - i11iIiiIii - Ii1Iiii1I1
def iIIIiIi1I1i ( ) :
 xbmc . executebuiltin ( 'Runscript("special://home/addons/plugin.program.NotBuffer3/speedtest.py")' )
 if 78 - 78: IIi11i1i1iI1 % o0O00oO + IiII111iI1ii1 / Ii11I1 % Ii1Iiii1I1 + ii1Ii1I1Ii11i
 if 91 - 91: IIi11i1i1iI1 % ooO00ooO000 . oOI1Ii1I1 + oO0OOoo0 + oOI1Ii1I1
 if 95 - 95: oO0OOoo0 + IiII111iI1ii1 * ii1Ii1I1Ii11i
 if 16 - 16: i1111I1I / oooO0 + ooO00ooO000 % IIi11i1i1iI1 - Ii11I1 . OO0OOOOoo0OOO
def iIi1iIIIiIiI ( params ) :
 if 62 - 62: i11iIiiIii % ii1Ii1I1Ii11i . ooo . ii1Ii1I1Ii11i
 ooOo0O0O0oOO0 = xbmcgui . Dialog ( ) . yesno ( "Esta usted seguro?" , 'Quiere cancelar la instalacion?' , '' , 'Todo el proceso sera abortado!' , yeslabel = 'Si' , nolabel = 'No' )
 if ooOo0O0O0oOO0 == 0 :
  return
 elif ooOo0O0O0oOO0 == 1 :
  dp . create ( "Por favor, espere" , "FRESHSTART IN PROGRESS" , '' , 'Please Wait' )
  try :
   for OOo0Oo0OOo0 , i1i11I , oOOo00O0OOOo in os . walk ( I1IiiI , topdown = True ) :
    i1i11I [ : ] = [ ii1i1i for ii1i1i in i1i11I if ii1i1i not in OOO00O ]
    for O0OOO0OOooo00 in oOOo00O0OOOo :
     try :
      os . remove ( os . path . join ( OOo0Oo0OOo0 , O0OOO0OOooo00 ) )
      os . rmdir ( os . path . join ( OOo0Oo0OOo0 , O0OOO0OOooo00 ) )
     except : pass
     if 10 - 10: oO00ooO0o0 + OoOO000
    for O0OOO0OOooo00 in i1i11I :
     try : os . rmdir ( os . path . join ( OOo0Oo0OOo0 , O0OOO0OOooo00 ) ) ; os . rmdir ( OOo0Oo0OOo0 )
     except : pass
  except : pass
 dialog . ok ( 'Completado' , 'Restauracion exitosa, Por favor, reinicie Kodi para que los cambios tengan exito.' , '' , '' )
 killxbmc ( )
 if 43 - 43: IIi11i1i1iI1 / Ii1Iiii1I1 % oOI1Ii1I1 - ii1Ii1I1Ii11i
i11i1Ii1 = ii1I1I111 ( )
oO0O000oOo = None
O0OOO0OOooo00 = None
OoOOOO = None
if 18 - 18: OO0ooOOO0OOO % i11iIiiIii . IIi11i1i1iI1 - O0o0OO0O00O
try : OoOOOO = urllib . unquote_plus ( i11i1Ii1 [ "mode" ] )
except : pass
try : O0OOO0OOooo00 = urllib . unquote_plus ( i11i1Ii1 [ "name" ] )
except : pass
try : oO0O000oOo = urllib . unquote_plus ( i11i1Ii1 [ "url" ] )
except : pass
if 80 - 80: oooO0 + OO0OOOOoo0OOO - Ii11I1 . oO0OOoo0 / oOI1Ii1I1 / oooO0
def oO00oOOoooO ( content , viewType ) :
 if wiz . getS ( 'auto-view' ) == 'true' :
  I1Iiii = wiz . getS ( viewType )
  if I1Iiii == '50' and Oo0oOOo >= 17 and oo00 == 'skin.estuary' : I1Iiii = '55'
  if I1Iiii == '500' and Oo0oOOo >= 17 and oo00 == 'skin.estuary' : I1Iiii = '50'
  wiz . ebi ( "Container.SetViewMode(%s)" % I1Iiii )
  if 34 - 34: oO0OOoo0 * o0O00oO - ooo - oooO0 - oO0OOoo0
if OoOOOO == None : iIiIiiIIiIIi ( )
if 42 - 42: Ii1Iiii1I1 * oooO0 % Ii11I1 - oO0OOoo0 % ooo
if 36 - 36: i11iIiiIii / OO0OOOOoo0OOO * IiII111iI1ii1 * IiII111iI1ii1 + oO0OOoo0 * i1111I1I
if 32 - 32: ooO00ooO000
if 50 - 50: OO0ooOOO0OOO + Ii11I1
if 31 - 31: oO0OOoo0
if 78 - 78: i11iIiiIii + oOI1Ii1I1 + o00oOOooOOo0o / oOI1Ii1I1 % IIi11i1i1iI1 % ooo
if 83 - 83: IIi11i1i1iI1 % o0O00oO % oOI1Ii1I1 % o00oOOooOOo0o . IiII111iI1ii1 % OoOO000
if 47 - 47: oOI1Ii1I1
if 66 - 66: oooO0 - ooo
if 33 - 33: oooO0 / ooO00ooO000
if 12 - 12: Ii1Iiii1I1
if 2 - 2: Ii11I1 - oooO0 + i1111I1I . Ii1Iiii1I1
if 25 - 25: OO0OOOOoo0OOO
elif OoOOOO == 'maint' : Iii1iiIi1II ( O0OOO0OOooo00 )
elif OoOOOO == 'kodi17fix' : wiz . kodi17Fix ( )
elif OoOOOO == 'advancedsetting' : II1i ( O0OOO0OOooo00 )
elif OoOOOO == 'autoadvanced' : Iii ( ) ; wiz . refresh ( )
elif OoOOOO == 'removeadvanced' : o0ooO ( ) ; wiz . refresh ( )
elif OoOOOO == 'asciicheck' : wiz . asciiCheck ( )
elif OoOOOO == 'backupbuild' : wiz . backUpOptions ( 'build' )
elif OoOOOO == 'backupgui' : wiz . backUpOptions ( 'guifix' )
elif OoOOOO == 'backuptheme' : wiz . backUpOptions ( 'theme' )
elif OoOOOO == 'backupaddon' : wiz . backUpOptions ( 'addondata' )
elif OoOOOO == 'oldThumbs' : wiz . oldThumbs ( )
elif OoOOOO == 'clearbackup' : wiz . cleanupBackup ( )
elif OoOOOO == 'convertpath' : wiz . convertSpecial ( I1IiiI )
elif OoOOOO == 'currentsettings' : oo0o0O0Oooooo ( )
elif OoOOOO == 'fullclean' : III11iiii11i1 ( ) ; wiz . refresh ( )
elif OoOOOO == 'clearcache' : IIIiIiI ( ) ; wiz . refresh ( )
elif OoOOOO == 'clearpackages' : wiz . clearPackages ( ) ; wiz . refresh ( )
elif OoOOOO == 'clearcrash' : wiz . clearCrash ( ) ; wiz . refresh ( )
elif OoOOOO == 'clearthumb' : ooOo0OoO ( ) ; wiz . refresh ( )
elif OoOOOO == 'checksources' : wiz . checkSources ( ) ; wiz . refresh ( )
elif OoOOOO == 'checkrepos' : wiz . checkRepos ( ) ; wiz . refresh ( )
elif OoOOOO == 'freshstart' : I11I1IIiiII1 ( )
elif OoOOOO == 'forceupdate' : wiz . forceUpdate ( )
elif OoOOOO == 'forceprofile' : wiz . reloadProfile ( wiz . getInfo ( 'System.ProfileName' ) )
elif OoOOOO == 'forceclose' : wiz . killxbmc ( )
elif OoOOOO == 'forceskin' : wiz . ebi ( "ReloadSkin()" ) ; wiz . refresh ( )
elif OoOOOO == 'hidepassword' : wiz . hidePassword ( )
elif OoOOOO == 'unhidepassword' : wiz . unhidePassword ( )
elif OoOOOO == 'enableaddons' : enableAddons ( )
elif OoOOOO == 'toggleaddon' : wiz . toggleAddon ( O0OOO0OOooo00 , oO0O000oOo ) ; wiz . refresh ( )
elif OoOOOO == 'togglecache' : ii1iii1I1I ( O0OOO0OOooo00 ) ; wiz . refresh ( )
elif OoOOOO == 'toggleadult' : wiz . toggleAdult ( ) ; wiz . refresh ( )
elif OoOOOO == 'changefeq' : oO0o00oOOooO0 ( ) ; wiz . refresh ( )
elif OoOOOO == 'uploadlog' : uploadLog . Main ( )
elif OoOOOO == 'viewlog' : ii1iii11i1 ( )
elif OoOOOO == 'viewwizlog' : ii1iii11i1 ( o0oO0 )
elif OoOOOO == 'viewerrorlog' : Ooo0oOooo0 ( all = True )
elif OoOOOO == 'clearwizlog' : O00oO0 = open ( o0oO0 , 'w' ) ; O00oO0 . close ( ) ; wiz . LogNotify ( "[COLOR %s]%s[/COLOR]" % ( oo0OOo , Oo0Ooo ) , "[COLOR %s]Wizard Log Cleared![/COLOR]" % ooOOO00Ooo )
elif OoOOOO == 'purgedb' : I1iI ( )
elif OoOOOO == 'fixaddonupdate' : iIiii ( )
elif OoOOOO == 'removeaddons' : removeAddonMenu ( )
elif OoOOOO == 'removeaddon' : removeAddon ( O0OOO0OOooo00 )
elif OoOOOO == 'removeaddondata' : removeAddonDataMenu ( )
elif OoOOOO == 'removedata' : iiI1i1Iii111 ( O0OOO0OOooo00 )
elif OoOOOO == 'resetaddon' : i111I11i = wiz . cleanHouse ( IiI , ignore = True ) ; wiz . LogNotify ( "[COLOR %s]%s[/COLOR]" % ( oo0OOo , Oo0Ooo ) , "[COLOR %s]Addon_Data reset[/COLOR]" % ooOOO00Ooo )
elif OoOOOO == 'systeminfo' : systemInfo ( )
elif OoOOOO == 'restorezip' : IIiI1I1 ( 'build' )
elif OoOOOO == 'restoregui' : IIiI1I1 ( 'gui' )
elif OoOOOO == 'restoreaddon' : IIiI1I1 ( 'addondata' )
elif OoOOOO == 'restoreextzip' : I111IIiii1Ii ( 'build' )
elif OoOOOO == 'restoreextgui' : I111IIiii1Ii ( 'gui' )
elif OoOOOO == 'restoreextaddon' : I111IIiii1Ii ( 'addondata' )
elif OoOOOO == 'writeadvanced' : OoO00 ( O0OOO0OOooo00 , oO0O000oOo )
if 34 - 34: o0O00oO . IIi11i1i1iI1 % OoOO000
if 43 - 43: IiII111iI1ii1 - O0o0OO0O00O
elif OoOOOO == 'addons' : addonMenu ( O0OOO0OOooo00 )
elif OoOOOO == 'addoninstall' : addonInstaller ( O0OOO0OOooo00 , oO0O000oOo )
if 70 - 70: O0o0OO0O00O / ii1Ii1I1Ii11i % OO0ooOOO0OOO - oO0OOoo0
elif OoOOOO == 'savedata' : saveMenu ( )
elif OoOOOO == 'togglesetting' : wiz . setS ( O0OOO0OOooo00 , 'false' if wiz . getS ( O0OOO0OOooo00 ) == 'true' else 'true' ) ; wiz . refresh ( )
elif OoOOOO == 'managedata' : oOooO00o0O ( O0OOO0OOooo00 )
elif OoOOOO == 'whitelist' : wiz . whiteList ( O0OOO0OOooo00 )
if 47 - 47: O0o0OO0O00O
if 92 - 92: ii1Ii1I1Ii11i + o0O00oO % Ii11I1
if 23 - 23: o00oOOooOOo0o - ii1Ii1I1Ii11i + oO0OOoo0 - o0O00oO * o0O00oO . oO00ooO0o0
elif OoOOOO == 'login' : loginMenu ( )
elif OoOOOO == 'savelogin' : loginit . loginIt ( 'update' , O0OOO0OOooo00 )
elif OoOOOO == 'restorelogin' : loginit . loginIt ( 'restore' , O0OOO0OOooo00 )
elif OoOOOO == 'addonlogin' : loginit . loginIt ( 'clearaddon' , O0OOO0OOooo00 )
elif OoOOOO == 'clearlogin' : loginit . clearSaved ( O0OOO0OOooo00 )
elif OoOOOO == 'authlogin' : loginit . activateLogin ( O0OOO0OOooo00 ) ; wiz . refresh ( )
elif OoOOOO == 'updatelogin' : loginit . autoUpdate ( 'all' )
elif OoOOOO == 'importlogin' : loginit . importlist ( O0OOO0OOooo00 ) ; wiz . refresh ( )
if 47 - 47: OO0OOOOoo0OOO % IIi11i1i1iI1
elif OoOOOO == 'contact' : notify . contact ( iIiIIIi )
elif OoOOOO == 'settings' : wiz . openS ( O0OOO0OOooo00 ) ; wiz . refresh ( )
elif OoOOOO == 'opensettings' : id = eval ( oO0O000oOo . upper ( ) + 'ID' ) [ O0OOO0OOooo00 ] [ 'plugin' ] ; IiI1IIIII1I = wiz . addonId ( id ) ; IiI1IIIII1I . openSettings ( ) ; wiz . refresh ( )
if 35 - 35: oO0OOoo0 - oO0OOoo0 + Ii11I1 - OoOO000 - o00oOOooOOo0o
if 58 - 58: o0O00oO - O0o0OO0O00O - ii
if 96 - 96: IIi11i1i1iI1
elif OoOOOO == 'UNZIPROM' : UNZIPROM ( )
elif OoOOOO == 'viewIP' : viewIP ( )
elif OoOOOO == 'net' : net_tools ( )
elif OoOOOO == 'speed' : iIIIiIi1I1i ( )
if 82 - 82: o0O00oO + OoOO000 - ooo % OO0OOOOoo0OOO * i11iIiiIii
if 15 - 15: oOI1Ii1I1
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
