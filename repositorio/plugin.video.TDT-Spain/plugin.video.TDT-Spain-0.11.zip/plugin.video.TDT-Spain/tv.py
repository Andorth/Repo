# -*- coding: utf-8 -*-

import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import base64,codecs


"""
##############################################################
## SPECIAL THANKS TO INSIDE 4NDROID FOR ALL THE HELP!
## Basado en el addon The Machine !!
##############################################################
#
#           + TDT SPAIN +  By Netai Team - 05/03/2020 #
#
##############################################################
"""
"""  Agradecimientos colaboradores: """
# Tenpvnf n Urvfraoret cbe fh bevragnpvba l nlhqn ra yn rapevcgnpvba. # 

plugin_handle = int(sys.argv[1])
exec codecs.decode("6164646F6E203D2078626D636164646F6E2E4164646F6E2827706C7567696E2E766964656F2E5444542D537061696E27290D0A6D7973657474696E6773203D2078626D636164646F6E2E4164646F6E286964203D2027706C7567696E2E766964656F2E5444542D537061696E2729","\x68\x65\x78").decode('utf-8')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
ajustes = xbmc.translatePath(os.path.join(home, 'ajustes.png'))
tdt = xbmc.translatePath(os.path.join(home, 'tdt.jpg'))
Dep = xbmc.translatePath(os.path.join(home, 'deportes.jpg'))
Doc = xbmc.translatePath(os.path.join(home, 'documentales.jpg'))
pys = xbmc.translatePath(os.path.join(home, 'pelisyseries.jpg'))
Guia = xbmc.translatePath(os.path.join(home, 'tdt-guia.png'))
buscar = xbmc.translatePath(os.path.join(home, 'buscar.jpg'))
exec codecs.decode("6C6976655F736F75726365203D2020636F646563732E6465636F6465282775676763663A2F2F636E6667726F76612E70627A2F656E6A2F6A6B4B415432534920272C20275C7837325C7836665C7837345C7833315C78333327292E6465636F646528277574662D3827290D0A6C6976655F736F7572636532203D20636F646563732E6465636F6465282775676763663A2F2F636E6667726F76612E70627A2F656E6A2F51496D67444C524D272C20275C7837325C7836665C7837345C7833315C78333327292E6465636F646528277574662D38272920200D0A6C6976655F736F7572636533203D20636F646563732E6465636F6465282775676763663A2F2F636E6667726F76612E70627A2F656E6A2F4A7735644668494B272C20275C7837325C7836665C7837345C7833315C78333327292E6465636F646528277574662D38272920200D0A6C6976655F736F7572636534203D20636F646563732E6465636F6465282775676763663A2F2F636E6667726F76612E70627A2F656E6A2F556D387637764A38272C20275C7837325C7836665C7837345C7833315C78333327292E6465636F646528277574662D38272920200D0A6269656E76656E696461203D20636F646563732E6465636F6465282775676763663A2F2F636E6667726F76612E70627A2F656E6A2F6343416C774A6F61272C20275C7837325C7836665C7837345C7833315C78333327292E6465636F646528277574662D382729200D0A677569615F746474203D20636F646563732E6465636F6465282775676763663A2F2F6A6A6A2E63656274656E7A6E707662612D6771672E70627A2F6E7562656E2E637563272C20275C7837325C7836665C7837345C7833315C78333327292E6465636F646528277574662D3827290D0A677569615F7072656D69756D203D20636F646563732E6465636F6465282775676763663A2F2F6676617065627468766E2D67692E726B636E61667662612E70627A2F6E7562656E2D72612D6769272C275C7837325C7836665C7837345C7833315C78333327292E6465636F646528277574662D382729200D0A6B657967656E203D20636F646563732E6465636F6465282775676763663A2F2F636E6667726F76612E70627A2F656E6A2F594978334D7A4F78272C20275C7837325C7836665C7837345C7833315C78333327292E6465636F646528277574662D3827290D0A7265676578203D20276E616D653D282E2B3F2975726C3D282E2B296C6F676F3D282E2B3F29270D0A6D33755F7468756D625F7265676578203D20277476672D6C6F676F3D5B5C27225D282E2A3F295B5C27225D270D0A6D33755F7265676578203D202723282E2B3F292C282E2B295C732A282E2B295C732A270D0A6D33755F67756961203D20273C74642077696474683D22323530222076616C69676E3D22746F70223E282E2B3F293C2F74643E5C732A7C636C6173733D22696E64223E282E2B293C2F7370616E3E270D0A6D33755F677569615F7072656D69756D203D2027687265663D2268747470733A2F2F73696E63726F677569612D74762E657870616E73696F6E2E636F6D2F70726F6772616D6163696F6E2F282E2B3F29227C6E6F77616E646E6578742D70726F6772616D5F5F696E666F223E282E2B3F293C7C6368616E6E656C5F5F6C696E6B22207469746C653D22282E2B3F29227C6E6F77616E646E6578742D70726F6772616D5F5F696D6167652D6C696E6B22207469746C653D22282E2B3F2922270D0A6D33755F6576656E746F73203D20277469746C652D73656374696F6E2D776964676574223E3C7374726F6E673E282E2B3F293C2F7370616E3E7C636C6173733D226461696C79646179223E282E2B3F293C2F7370616E3E7C226461696C79686F7572223E282E2B3F293C2F7374726F6E673E7C636C6173733D226461696C79636F6D7065746974696F6E223E282E2B3F293C2F7370616E3E7C3C6120687265663D2222207469746C653D2253656D6966696E616C223E282E2B3F293C2F613E7C3C6920636C6173733D2269636F6E2D70616E74616C6C61223E3C2F693E282E2B3F293C2F7370616E3E270D0A755F74756265203D2027687474703A2F2F7777772E796F75747562652E636F6D270D0A6469726563746F73203D20636F646563732E6465636F64652827756767633A2F2F76632D67626279662E7A792F272C275C7837325C7836665C7837345C7833315C78333327292E6465636F646528277574662D3827290D0A6C6963656E6369615F6164646F6E203D206164646F6E2E67657453657474696E6728276C6963656E6369615F6164646F6E27290D0A627573636172203D2078626D632E7472616E736C61746550617468286F732E706174682E6A6F696E28686F6D652C20276275736361722E6A70672729290D0A4775696120203D2078626D632E7472616E736C61746550617468286F732E706174682E6A6F696E28686F6D652C20277464742D677569612E706E672729290D0A6D796462203D20275B5C27225D282E2A3F295B5C27225D270D0A746578746F5F7265676578203D2027746578746F313D5B5C27225D282E2A3F295B5C27225D5C732A746578746F323D5B5C27225D282E2A3F295B5C27225D5C732A746578746F333D5B5C27225D282E2A3F295B5C27225D5C732A27","\x68\x65\x78").decode('utf-8')
aviso = addon.getSetting('aviso')
licencia_addon = addon.getSetting('licencia_addon')
regex_premium = 'channel__link" title="Programación(.*?)"|<img src="(.*?)"|image-link" title="(.*?)"|-program__info">(.*?)</p>'
lista_premium = 'https://sincroguia-tv.expansion.com/ahora-en-tv'
premium_regex = 'expansion.com/programacion/(.*?)"|nowandnext-program__info">(.*?)<|channel__link" title="(.*?)"|nowandnext-program__image-link" title="(.*?)"'
guia_peliculas = 'https://sincroguia-tv.expansion.com/peliculas'
guia_series = 'https://sincroguia-tv.expansion.com/series'
pelis_regex = 'program__name-link" title="(.*?)"|pagespeed-lazy-src="(.*?)"|alt="(.*?)"|m-program__info">(.*?) en'
series_regex = 'program__name-link" title="(.*?)"|pagespeed-lazy-src="(.*?)"|alt="(.*?)"|m-program__info">(.*?) en'
guia_deporte = 'https://sincroguia-tv.expansion.com/deportes'
deporte_regex = 'program__name-link" title="(.*?)"|pagespeed-lazy-src="(.*?)"|alt="(.*?)"|m-program__info">(.*?) en'

def mensaje():
	

	
	if aviso == 'true':
		
		try:
			content = make_request(bienvenida)
			match = re.compile(texto_regex).findall(content)
			for texto1,texto2,texto3 in match:
				try:
		
		
					msg1 = texto1
					msg2 = texto2
					msg3 = texto3

					line1 = "" + msg1 + ""
					line2 = "" + msg2 + ""
					line3 = ""+ msg3 +""

					xbmcgui.Dialog().ok("Real Stream", line1, line2, line3)
				except:
					pass
							
		except:
			pass			
			
def settings():
    addon.openSettings()
	
def searchtv(): 	
## THIS IS THE SEARCH FUNCTION WHICH SEARCHES THE LIVE TV 
	try:
		keyb = xbmc.Keyboard('', 'Canal a buscar')
		keyb.doModal()
		if (keyb.isConfirmed()):
			searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
			content1 = make_request(live_source)
			content2 = make_request(live_source2)
			content3 = make_request(live_source3)
			content4 = make_request(live_source4)

			match1 = re.compile(m3u_regex).findall(content1)
			match2 = re.compile(m3u_regex).findall(content2)
			match3 = re.compile(m3u_regex).findall(content3)
			match4 = re.compile(m3u_regex).findall(content4)

			for thumb, name, url in match1+match2+match3+match4:
				if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
					m3u_playlist(name, url, thumb)
	except:
		pass

def removeAccents(s):
## THIS REMOVES ACCENTS FROM TEXT SO THAT PYTHON CAN READ IT
	return ''.join((c for c in unicodedata.normalize('NFD', s.decode('utf-8')) if unicodedata.category(c) != 'Mn'))
					
def read_file(file):
## THIS FUNCTION READS THE SOURCE FILES
    try:
        f = open(file, 'r')
        content = f.read()
        f.close()
        return content
    except:
        pass
def OPEN_URL(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36')
        req.add_header('Referer', '%s'%url)
        req.add_header('Connection', 'keep-alive')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
		
def make_request(url):
## THIS FUNCTION GETS THE FILES FROM URL AND READS THEM TO CACHE/MEM
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0')
		response = urllib2.urlopen(req)	  
		link = response.read()
		response.close()  
		return link
	except urllib2.URLError, e:
		print 'We failed to open "%s".' % url
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code	
		if hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason
			

			
def menu():

	add_link_info('[B][COLOR white]TDT TV:[/COLOR][/B]',icon, fanart)
	add_dir('[COLOR orange]TDT[/COLOR]', u_tube, 2, tdt, fanart)
	add_dir('[COLOR orange]Ajustes[/COLOR]', u_tube, 11, ajustes, fanart)	
	add_link_info('[COLOR white]GUIAS EVENTOS:[/COLOR]',icon, fanart)
	add_dir('[COLOR orange]Guia TDT[/COLOR]', u_tube, 9, Guia, fanart)
	
def premium():

	add_link_info('[B][COLOR white]TDT TV:[/COLOR][/B]',icon, fanart)
	add_dir('[COLOR white][B]Buscar Canal[/B][/COLOR]', 'searchlink', 98, buscar, fanart)
	add_dir('[COLOR orange]TDT[/COLOR]', u_tube, 2, tdt, fanart)
	add_dir('[COLOR orange]Cine y Series[/COLOR]', u_tube, 5, pys, fanart)
	add_dir('[COLOR orange]Deportes[/COLOR]', u_tube, 6, Dep, fanart)
	add_dir('[COLOR orange]Documental[/COLOR]', u_tube, 7, Doc, fanart)
	add_dir('[COLOR orange]Ajustes[/COLOR]', u_tube, 11, ajustes, fanart)	
	add_link_info('[COLOR white]GUIAS EVENTOS:[/COLOR]',icon, fanart)
	add_dir('[COLOR orange]Guia Premium[/COLOR]', u_tube, 10, Guia, fanart)
	add_dir('[COLOR orange]Peliculas ahora ...[/COLOR]', u_tube, 12, Guia, fanart)
	add_dir('[COLOR orange]Series ahora ...[/COLOR]', u_tube, 13, Guia, fanart)
	add_dir('[COLOR orange]Deportes ahora ...[/COLOR]', u_tube, 14, Guia, fanart)			
	
def guia_online():
    link = OPEN_URL(guia_tdt)
    match=re.compile('<td width="250" valign="top">(.+?)</td>\s*|class="ind">(.+)</span>').findall(link)
    for name, evento in match:
        
		addDir2('[COLOR gold]%s[/COLOR] [COLOR white]%s[/COLOR]' %(name,evento),url,9,'')
				
def guia_premium():
	content = make_request(lista_premium)
	match = re.compile(regex_premium).findall(content)
	for name, img, evento, hora in match:
		try:
		
			add_dir('[COLOR gold]%s[/COLOR] [COLOR white]%s[/COLOR] [COLOR orange]%s[/COLOR]' %(name,evento,hora),u_tube,10,img, fanart)
		
		except:
			pass

			

def guia_Cine():

	content = make_request(guia_peliculas)
	match = re.compile(pelis_regex).findall(content)
	for name, img, pelicula, hora in match:
		try:
		
			add_dir('[COLOR gold]%s[/COLOR] [COLOR white]%s[/COLOR] [COLOR orange]%s[/COLOR]' %(name,pelicula,hora),u_tube,12,img, fanart)
		
		except:
			pass	

def guia_serie():

	content = make_request(guia_series)
	match = re.compile(series_regex).findall(content)
	for name, img, serie, hora in match:
		try:
		
			add_dir('[COLOR gold]%s[/COLOR] [COLOR white]%s[/COLOR] [COLOR orange]%s[/COLOR]' %(name,serie,hora),u_tube,13,img, fanart)
		
		except:
			pass
			
def guia_deportes():

	content = make_request(guia_deporte)
	match = re.compile(deporte_regex).findall(content)
	for name, img, serie, hora in match:
		try:
		
			add_dir('[COLOR gold]%s[/COLOR] [COLOR white]%s[/COLOR] [COLOR orange]%s[/COLOR]' %(name,serie,hora),u_tube,14,img, fanart)
		
		except:
			pass

			
def livetv_online():
## GET THE LIVE TV 
	content = make_request(live_source)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass

def livetv_online2():
## GET THE LIVE TV 
	content = make_request(live_source2)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass			

def livetv_online3():
## GET THE LIVE TV 
	content = make_request(live_source3)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass			

def livetv_online4():
## GET THE LIVE TV 
	content = make_request(live_source4)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass

def livetv_online5():
## GET THE LIVE TV 
	content = make_request(live_source5)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass

		
				
def playlist(name, url, thumb):	
## AFTER GETTING THE MOVIES OR DOCS CATEGORIE OR SEARCHING THESE THIS WILL SORT AND LIST THEM AS DIRS OR LINKS ETC
	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')			
			add_dir(name, url, '', thumb, thumb)			
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		if 'youtube.com/watch?v=' in url:
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % (url.split('=')[-1])
		elif 'dailymotion.com/video/' in url:
			url = url.split('/')[-1].split('_')[0]
			url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	
		else:			
			url = url
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			add_link(name, url, 1, thumb, thumb)			
		else:				
			add_link(name, url, 1, icon, fanart)	

def m3u_playlist(name, url, thumb):	
## AFTER GETTING THE LIVETV CATEGORIE OR SEARCHING LIVETV THEN THIS WILL SORT AND LIST THEM AS DIRS OR LINKS ETC
	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')			
			add_dir(name, url, '', thumb, thumb)			
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		if 'youtube.com/watch?v=' in url:
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % (url.split('=')[-1])
		elif 'dailymotion.com/video/' in url:
			url = url.split('/')[-1].split('_')[0]
			url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	
		else:			
			url = url
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			add_link(name, url, 1, thumb, thumb)			
		else:				
			add_link(name, url, 1, icon, fanart)	

def play_video(name,url):
## THIS HAPPENS WHEN A LINK IS CLICKED ON IF THE URL CONTAINS .M3U8 THEN IT WILL DO THE "IF" PART AN IF NOT IT WILL DO THE "ELSE" BIT!
	if '.m3u8'  or '.ts' in url:
		name = re.sub('\s+', ' ', name).strip()	
		url = url.replace("http://","plugin://plugin.video.f4mTester/?url=http://").replace(".m3u8",".ts")
		url = url + "&amp;streamtype=TSDOWNLOADER&name=%s" %name
		media_url = url
		item = xbmcgui.ListItem(name, path = media_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		return
	else:	
		media_url = url
		name = re.sub('\s+', ' ', name).strip()
		item = xbmcgui.ListItem(name, path = media_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		return	

def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param

def add_dir(name, url, mode, iconimage, fanart):
## ADDS THE DIRECTORIES
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		u = 'plugin://plugin.video.youtube/%s/%s/' % (url.split( '/' )[-2], url.split( '/' )[-1])
		ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
		return ok		
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok
	
def addDir2(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def add_link(name, url, mode, iconimage, fanart):
## ADDS THE LINKS
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)	
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz) 

def add_link_info(name, iconimage, fanart):
## ADDS THE TEXT ONLY LINKS WITH NO CLICK ACTION
	u = sys.argv[0] + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)	
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'false') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz) 
	
def add_link_dummy(iconimage, fanart):
## ADDS THE BLANK SPACER IN MENU WITH NO CLICK ACTION
	u = sys.argv[0] + "&iconimage=" + urllib.quote_plus(iconimage)	
	liz = xbmcgui.ListItem(iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'false') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)  

params = get_params()
url = None
name = None
mode = None
iconimage = None

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass  

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)
print "iconimage: " + str(iconimage)		


if mode == None or url == None or len(url) < 1:

	
	try:
		content = make_request(keygen)
		match = re.compile(mydb).findall(content)
		for key in match:
		
			if key == licencia_addon:
			
				premium()
			
				xbmcgui.Dialog().ok("TDT SPAIN:" , "[COLOR lime][B]+ FULL ON +[/B][/COLOR] [COLOR gold] TV no disponible fuera de España. Utilice una vpn con servidor en España.[/COLOR]") 
				
				if aviso == 'true':
	
					mensaje()
					
			else:
			
				menu()
				
				xbmcgui.Dialog().ok("TDT SPAIN:" , "[COLOR red][B]+ BASIC ON +[/B][/COLOR] [COLOR gold] TV no disponible fuera de España. Utilice una vpn con servidor en España.[/COLOR]") 
				
				if aviso == 'true':
	
					mensaje()
	except:
		pass
				
	
elif mode == 1:
	play_video(name,url)


elif mode == 3:
	movies_online()
	
elif mode == 4:
	docs_online()

elif mode == 98:
	searchtv()

elif mode == 99:
	search()
	
elif mode == 2:
	livetv_online()

elif mode == 5:
	livetv_online2()

elif mode == 6:
	livetv_online3()

elif mode == 7:
	livetv_online4()

elif mode == 8:
	livetv_online5()

elif mode == 9:
	guia_online()
	
elif mode == 10:
	guia_premium()
	
elif mode == 11:
	settings()
	
elif mode == 12:
	guia_Cine()
	
elif mode == 13:
	guia_serie()
	
elif mode == 14:
	guia_deportes()

	
xbmcplugin.endOfDirectory(plugin_handle)