# -*- coding: utf-8 -*-
# Real stream by Netai 2019 
# Version 0.5.5 
#
############################################
#
# Incluido Script ResolveURL Por Jsergio.
#
############################################
import urllib, urllib2, sys, re, os, unicodedata
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import cookielib,webbrowser
import traceback,datetime,HTMLParser,httplib
import urlresolver
import cookielib,base64
import requests	
import plugintools
addon = xbmcaddon.Addon('plugin.video.Real.stream')
addon_version = addon.getAddonInfo('version')
plugin_handle = int(sys.argv[1])
user = 'gruponetai/'   
mysettings = xbmcaddon.Addon(id = 'plugin.video.Real.stream')
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
#Imagenes
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
extended = xbmc.translatePath(os.path.join(home, 'extended_info.png'))
buscar = xbmc.translatePath(os.path.join(home, 'buscar.png'))
pair = xbmc.translatePath(os.path.join(home, 'pair.png'))
theMovieDB = xbmc.translatePath(os.path.join(home, 'theMovieDB.jpg'))
novedades = xbmc.translatePath(os.path.join(home, 'estrenos.png'))
estrenos = xbmc.translatePath(os.path.join(home, 'encines.jpg'))
recomendadas = xbmc.translatePath(os.path.join(home, 'recomendadas.jpg'))
p_accion = xbmc.translatePath(os.path.join(home, 'accion.jpg'))
animacion = xbmc.translatePath(os.path.join(home, 'animacion.jpg'))
aventuras = xbmc.translatePath(os.path.join(home, 'aventuras.jpg'))
belico = xbmc.translatePath(os.path.join(home, 'belico.jpg'))
cifi = xbmc.translatePath(os.path.join(home, 'ciencia-ficcion.jpg'))
comedia = xbmc.translatePath(os.path.join(home, 'comedia.jpg'))
crimen = xbmc.translatePath(os.path.join(home, 'crimen.jpg'))
drama = xbmc.translatePath(os.path.join(home, 'drama.jpg'))
familiar = xbmc.translatePath(os.path.join(home, 'familiar.jpg'))
fantasia = xbmc.translatePath(os.path.join(home, 'fantasia.jpg'))
historia = xbmc.translatePath(os.path.join(home, 'historia.jpg'))
superheroes = xbmc.translatePath(os.path.join(home, 'marvel.png'))
misterio = xbmc.translatePath(os.path.join(home, 'misterio.jpg'))
musical = xbmc.translatePath(os.path.join(home, 'musical.jpg'))
romance = xbmc.translatePath(os.path.join(home, 'romance.jpg'))
spain = xbmc.translatePath(os.path.join(home, 'spain.jpg'))
suspense = xbmc.translatePath(os.path.join(home, 'suspense.jpg'))
terror = xbmc.translatePath(os.path.join(home, 'terror.jpg'))
thriller = xbmc.translatePath(os.path.join(home, 'thriller.jpg'))
western = xbmc.translatePath(os.path.join(home, 'western.jpg'))
sagas = xbmc.translatePath(os.path.join(home, 'sagas_cine.jpg'))
calidad4k = xbmc.translatePath(os.path.join(home, '4k.jpg'))
torrent = xbmc.translatePath(os.path.join(home, 'torrent.jpg'))
#Menus
menu_pelis = xbmc.translatePath(os.path.join(home, 'peliculas.png'))
ajustes = xbmc.translatePath(os.path.join(home, 'ajustes.png'))
vid = xbmc.translatePath(os.path.join(home, 'videoteca.png'))
favicon = xbmc.translatePath(os.path.join(home, 'favorites.png'))
resolver = xbmc.translatePath(os.path.join(home, 'resolver.png'))
test = xbmc.translatePath(os.path.join(home, 'test.png'))
videotutoriales = xbmc.translatePath(os.path.join(home, 'video-tutoriales.png'))
#Ajustes
mostrar_cat = addon.getSetting('mostrar_cat')
videos = addon.getSetting('videos')
activar = addon.getSetting('activar')
favcopy = addon.getSetting('favcopy')
anticopia = addon.getSetting('anticopia')
notificar = addon.getSetting('notificar')
mostrar_bus = addon.getSetting('mostrar_bus')
restante = addon.getSetting('restante')
aviso = addon.getSetting('aviso')
RealStream_Settings = addon.getSetting('RealStream_Settings')
Resolver_Settings = addon.getSetting('Resolver_Settings')
restante = addon.getSetting('restante')
fav = addon.getSetting('fav') 
texto = 'aHR0cDovL25ldGFpLmV1L3JlYWxzdHJlYW0v'.decode('base64')
txt = 'bienvenida'
txt2 = 'bienvenida' #.decode('base64')
Forceupdate = addon.getSetting('Forceupdate')
if Forceupdate == 'true':  
    xbmc.executebuiltin('UpdateAddonRepos()')
    xbmc.executebuiltin('UpdateLocalAddons()')
extension = '.txt' #.decode('base64')	
#regexs
bienvenida = texto + txt + extension
u_tube = 'http://www.youtube.com'
urly = 'aHR0cDovL3kzei5zag=='.decode('base64')
decode32 = '.xsl.pt'
lnk3 = '/master/'
myurl = urly + decode32
texto_regex = 'texto1=[\'"](.*?)[\'"]\s*texto2=[\'"](.*?)[\'"]\s*texto3=[\'"](.*?)[\'"]\s*'
m3u_thumb_regex = 'tvg-logo=[\'"](.*?)[\'"]'
#m3u_regex = '#(.+?),(.+)\s*(.+)\s*(.*)'
m3u_regex ='#(.+?),(.+)\s*(.+)\s*(.+)\s*(.*)'
tutoriales_regex = '#(.+?),(.+)\s*(.+)'
url_regex = 'lk=[\'"](.*?)[\'"]\s*lk1=[\'"](.*?)[\'"]\s*lk2=[\'"](.*?)[\'"]\s*lk3=[\'"](.*?)[\'"]\s*lk4=[\'"](.*?)[\'"]\s*lk5=[\'"](.*?)[\'"]\s*lk6=[\'"](.*?)[\'"]\s*lk7=[\'"](.*?)[\'"]\s*lk8=[\'"](.*?)[\'"]\s*lk9=[\'"](.*?)[\'"]\s*lk10=[\'"](.*?)[\'"]\s*lk11=[\'"](.*?)[\'"]\s*lk12=[\'"](.*?)[\'"]\s*lk13=[\'"](.*?)[\'"]\s*lk14=[\'"](.*?)[\'"]\s*lk15=[\'"](.*?)[\'"]\s*lk16=[\'"](.*?)[\'"]\s*lk17=[\'"](.*?)[\'"]\s*lk18=[\'"](.*?)[\'"]\s*lk19=[\'"](.*?)[\'"]\s*lk20=[\'"](.*?)[\'"]\s*lk21=[\'"](.*?)[\'"]\s*lk22=[\'"](.*?)[\'"]\s*lk23=[\'"](.*?)[\'"]\s*'
#rapidvideo = 'source src=[\'"](.*?)[\'"]'
rapidvideo = 'source src=[\'"](.*?)[\'"]\s*title=[\'"](.*?)[\'"]'
lnk_regex = 'db=[\'"](.*?)[\'"]\s*db0=[\'"](.*?)[\'"]\s*db1=[\'"](.*?)[\'"]\s*db2=[\'"](.*?)[\'"]\s*db3=[\'"](.*?)[\'"]\s*db4=[\'"](.*?)[\'"]\s*db5=[\'"](.*?)[\'"]\s*db6=[\'"](.*?)[\'"]\s*db7=[\'"](.*?)[\'"]\s*db8=[\'"](.*?)[\'"]\s*db9=[\'"](.*?)[\'"]\s*db10=[\'"](.*?)[\'"]\s*db11=[\'"](.*?)[\'"]\s*db12=[\'"](.*?)[\'"]\s*db13=[\'"](.*?)[\'"]\s*db14=[\'"](.*?)[\'"]\s*db15=[\'"](.*?)[\'"]\s*db16=[\'"](.*?)[\'"]\s*db17=[\'"](.*?)[\'"]\s*db18=[\'"](.*?)[\'"]\s*db19=[\'"](.*?)[\'"]\s*db20=[\'"](.*?)[\'"]\s*db21=[\'"](.*?)[\'"]\s*db22=[\'"](.*?)[\'"]\s*db23=[\'"](.*?)[\'"]\s*db24=[\'"](.*?)[\'"]\s*'
visita_regex = '[\'"](.*?)[\'"]'
server = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tLw=='.decode('base64')
lnk = server + user
lnk2 = 'Realstream' #.decode('base64')
ong_regex = 'video=[\'"](.*?)[\'"]'
conecta = lnk + lnk2 + lnk3
visitante = 'aHR0cDovL2JpdC5seS8yS0pZZVVp'.decode('base64')
#categorias
db = conecta + 'todas.m3u'
op1 = conecta + 'estrenos.m3u' 
op = conecta + 'novedades.m3u'
op2 = conecta + 'recomendadas.m3u'
op3 = conecta + 'accion.m3u'
op4 = conecta + 'animacion.m3u'
op5 = conecta + 'aventuras.m3u'
op6 = conecta + 'belico.m3u'
op7 = conecta + 'cifi.m3u'
op8 = conecta + 'comedia.m3u'
op9 = conecta + 'crimen.m3u'
op10 = conecta + 'drama.m3u'
op11 = conecta + 'familiar.m3u'
op12 = conecta + 'fantasia.m3u'
op13 = conecta + 'historia.m3u'
op14 = conecta + 'misterio.m3u'
op15 = conecta + 'musical.m3u'
op16 = conecta + 'romance.m3u'
op17 = conecta + 'thriller.m3u'
op18 = conecta + 'suspense.m3u'
op19 = conecta + 'terror.m3u'
op20 = conecta + 'western.m3u'
op21 = conecta + 'spain.m3u'
op22 = conecta + 'superheroes.m3u'
op23 = conecta + 'sagas.m3u'
op24 = conecta + '4k.m3u'
op25 = conecta + 'videotutoriales.m3u'

def search(): 


## ESTA FUNCION BUSCA EN LAS LISTAS m3u DENTRO DE LAS CATEGORIAS. | Cuantas mas categorias, mas lento ira el buscador a no ser que hagamos buscadores individuales.
	try:
		keyb = xbmc.Keyboard('', 'Busqueda por titulo, año, servidor:')
		keyb.doModal()
		if (keyb.isConfirmed()):
		
			searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
			content_db = make_request(db)
			match = re.compile(m3u_regex).findall(content_db)
			
			for thumb, name, url, id, trailer in match:
				if re.search(searchText, removeAccents(name.replace(' ', ' ')), re.IGNORECASE):
					m3u_playlist(name, url, thumb, id, trailer)
	except:
		pass
#if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):		
def check_version():
	
	content2 = make_request(visitante)
	match = re.compile(visita_regex).findall(content2)
	for version in match:
		try:

			import xbmc
			import xbmcaddon

			__addon__ = xbmcaddon.Addon()
			__addonname__ = __addon__.getAddonInfo('name')
			__icon__ = __addon__.getAddonInfo('icon')
 
			line1 = "" +version+ ""
			time = 3000 #in miliseconds
 
			xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%(__addonname__,line1, time, __icon__))
			
			
		except:
			pass
	

def mensaje(): 

	
	videos = addon.getSetting('videos')
	if videos == 'true':
	
		try:

			import urlresolver
			from urlresolver import common
			import random
			from random import choice
			play=xbmc.Player()
			vid = ['iHJAKUyjomI','_pqbkWaTGX0','5sSQINZQjfU','hEl07wzNkaE','hflGH4jKU0k','1qP8wVmQ1eI']
			random_vid = random.choice(vid) 
			url = 'https://www.youtube.com/watch?v=%s' % random_vid
			url=urlresolver.HostedMediaFile(url).resolve() 
			play.play(url)
		
			videos == 'false'
			
		except: 
			pass
	

	content = make_request(bienvenida)
	match = re.compile(texto_regex).findall(content)
	for texto1,texto2,texto3 in match:
		try:
		
		
			msg1 = texto1
			msg2 = texto2
			msg3 = texto3
			
			
			line1 = "[COLOR=red][B]" + msg1 + "[/B][/COLOR]"
			line2 = "[COLOR yellow]" + msg2 + "[/COLOR]"
			line3 = "[COLOR yellow]" + msg3 + "[/COLOR]"

			xbmcgui.Dialog().ok("Real Stream", line1, line2, line3)
		
		except: menu()
			
			
	
	
			
	if not xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
		xbmcgui.Dialog().ok("El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]","[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]")


		
def removeAccents(s):
## Nos cargamos los acentos, phyton no los usa ni los reconoce. 
	return ''.join((c for c in unicodedata.normalize('NFD', s.decode('utf-8')) if unicodedata.category(c) != 'Mn'))
					
def read_file(file):
## FUNCION QUE LEE LOS FICHEROS:
    try:
        f = open(file, 'r')
        content = f.read()
        f.close()
        return content
    except:
        pass

def make_request(url):
##ESTA FUNCION lee las url declaradas donde estan los videos. ||
	try:
		req = urllib2.Request(url)
#		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0')
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:55.0) Gecko/20100101 Firefox/55.0')
		response = urllib2.urlopen(req)	  
		link = response.read()
		response.close()  
		return link
	except urllib2.URLError, e:
		print 'We failed to open "%s".' % url
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code	
		if hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason
			
def OPEN_URL(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36')
        req.add_header('Referer', '%s'%url)
        req.add_header('Connection', 'keep-alive')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link


def conf_menu():

    if activar == 'true':
	add_dir('[COLOR orange]Menu Peliculas[/COLOR] ', 'movieDB', 116, menu_pelis, fanart)

	
    if RealStream_Settings == 'true':
        add_dir('[COLOR orange]Ajustes[/COLOR]', 'Settings', 119, ajustes, fanart)

    		
	if mostrar_cat == 'true':
		peliculas()
		
	if Resolver_Settings == 'true':
		menu_resolver_set()
		menu_resolveurl_set()
        
	if anticopia == 'false':

		line1 = "[COLOR=red][B]Activacion del Addon:[/B][/COLOR]"
		line2 = "[COLOR aqua]Este addon necesita las siguientes dependencias, Script.extendedinfo, Script.UrlResolver, Program.favoritos-realstream para su correcto funcionamiento. Puede descargarlas desde http://netai.eu/netai[/COLOR]"
		line3 = "[COLOR gold]Por favor, vaya a ajustes y active las pestañas: Activar addon, Y la opcion tengo las siguientes depencencias, Script.extendedinfo, y script.Urlresolver instaladas. Muchas gracias, Netai Team.[/COLOR]"

		xbmcgui.Dialog().ok("Real Stream", line1, line2, line3)
		
def buscar_id():
    add_dir('[COLOR orange]Buscador por id[/COLOR]', u_tube, 127, theMovieDB, fanart)

def menu():
	add_dir('[COLOR orange]The movie DB[/COLOR]', 'movieDB', 99, theMovieDB, fanart)
	add_dir('[COLOR orange]Buscador por id[/COLOR]', u_tube, 127, theMovieDB, fanart)
	add_dir('[COLOR orange]Video tutoriales[/COLOR]',u_tube,125,videotutoriales,fanart)
#	add_dir('[COLOR orange]Ajustes[/COLOR]', 'Settings', 119, ajustes, fanart)
#	add_dir('[COLOR orange]Mis enlaces[/COLOR]', 'video', 120, videoteca, fanart)
#   add_dir('[COLOR lime]The movie DB[/COLOR]', 'movieDB', 99, theMovieDB, fanart)
#	add_dir('[COLOR orange]Ajustes[/COLOR]', 'Settings', 119, ajustes, fanart)
#	add_dir('[COLOR red]Autorizar[/COLOR] [COLOR aquamarine][B]OPENLOAD[/B][/COLOR]', 'movieDB', 97, pair, fanart)
#	add_dir('[COLOR orange]Mis enlaces[/COLOR]', 'movieDB', 120, vid, fanart)
	add_dir('[COLOR orange]Autorizar[/COLOR] [COLOR blue][B]OPENLOAD[/B][/COLOR]', 'movieDB', 97, pair, fanart)
#	add_dir('[COLOR orange] Test enlaces [/COLOR]', 'testlinks', 128, test, fanart)
	conf_menu()
	
	
def favoritos():

    if xbmc.getCondVisibility('System.HasAddon(plugin.program.favoritos-realstream)'):
	
		xbmc.executebuiltin('RunAddon(plugin.program.favoritos-realstream)')
	
	        if favcopy == 'true':
	
	            xbmcgui.Dialog().ok("[COLOR orange]Real Stream Agradecimientos[/COLOR]" , "[COLOR gold]Netai quiere agradecer el genial trabajo de [/COLOR][COLOR lime][B]Spoyser[/B][/COLOR][COLOR gold] Autor de este genial script que originalmente se conoce como:[/COLOR]" , "[COLOR lime][B]Program.super.favorites[/B][/COLOR]" , "Usted puede descargar el script original desde el repositorio de Kodi >Addons de programas> program.super.favorites")

                addon.setSetting('Favoritos-anuncio', 'false')
    else:
	    
		xbmcgui.Dialog().ok("El programa Real stream Favoritos No esta instalado" , "[COLOR green]Necesario AddOn externo para agregar tus peliculas a favoritas dentro del addon.[/COLOR]","[COLOR yellow]Puedes agregarlo desde http://netai.eu/netai/ agregando la fuente a tu Kodi, instalar desde archivo zip.[/COLOR]")

def Real_stream_settings():
    addon.openSettings()
	
def urlresolver_settings():
    urlresolver.display_settings()

def menu_resolver_set():
    add_dir('[COLOR orange]Ajustes URL RESOLVER[/COLOR]', 'resolve', 120, resolver, fanart)	

def resolveurl_settings():

    xbmcaddon.Addon('script.module.resolveurl').openSettings()

def menu_resolveurl_set():
    add_dir('[COLOR orange]Ajustes RESOLVE URL[/COLOR]', 'resolve', 140, resolver, fanart)
	
def peliculas():
	add_dir('[COLOR yellow]Buscador[/COLOR]', 'search', 111, buscar, fanart)
	add_dir('[COLOR orange]Novedades[/COLOR]',u_tube,3,novedades,fanart)
	add_dir('[COLOR orange]Estrenos[/COLOR]',u_tube,2,estrenos,fanart)
	add_dir('[COLOR orange]Accion[/COLOR]',u_tube,5,p_accion,fanart)
	add_dir('[COLOR orange]Animacion[/COLOR]',u_tube,6,animacion,fanart)
	add_dir('[COLOR orange]Aventuras[/COLOR]',u_tube,7,aventuras,fanart)
	add_dir('[COLOR orange]Ciencia Ficcion[/COLOR]',u_tube,9,cifi,fanart)
	add_dir('[COLOR orange]Comedia[/COLOR]',u_tube,10,comedia,fanart)
	add_dir('[COLOR orange]Drama[/COLOR]',u_tube,12,drama,fanart)
	add_dir('[COLOR orange]Fantasia[/COLOR]',u_tube,14,fantasia,fanart)
	add_dir('[COLOR orange]Misterio[/COLOR]',u_tube,16,misterio,fanart)
	add_dir('[COLOR orange]Musical[/COLOR]',u_tube,17,musical,fanart)
	add_dir('[COLOR orange]Romance[/COLOR]',u_tube,18,romance,fanart)
	add_dir('[COLOR orange]Thriller[/COLOR]',u_tube,19,thriller,fanart)
	add_dir('[COLOR orange]Suspense[/COLOR]',u_tube,20,suspense,fanart)
	add_dir('[COLOR orange]Terror[/COLOR]',u_tube,21,terror,fanart)
	add_dir('[COLOR orange]Western[/COLOR]',u_tube,22,western,fanart)
	add_dir('[COLOR orange]Super heroes[/COLOR]',u_tube,24,superheroes,fanart)
	add_dir('[COLOR orange]Sagas[/COLOR]',u_tube,25,sagas,fanart)
		
def get_info_movie():

    # prompt the user to input search text
    kb = xbmc.Keyboard('', 'Titulo de la pelicula')
    kb.doModal()
    if not kb.isConfirmed():
        return None;
    name = kb.getText().strip()
	

    if xbmc.getCondVisibility('system.platform.android'):
	
	opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/search?query=' +name+ '&language=es-ES'  ) )
	
        
	return 'android'

    elif xbmc.getCondVisibility('system.platform.windows'):
	
	opensite = webbrowser . open('https://www.themoviedb.org/search?query=' +name+ '&language=es-ES')
  
	
	return 'windows'
	
def Novedades(): 		
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
def Estrenos():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op1)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
def Recomendadas(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op2)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
def Accion(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op3)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass

def Animacion(): 
	
## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op4)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
def Aventuras():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op5)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
def Belico(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op6)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
def Cifi(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op7)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
			
def Comedia(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op8)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
			
def Crimen(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op9)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
			
def Drama(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op10)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
def Familiar():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op11)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
			
def Fantasia(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op12)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
			
def Historia(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op13)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
def Misterio():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op14)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
			
def Musical():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op15)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
def Romance():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op16)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
			
def Thriller(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op17)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
			
def Suspense():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op18)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
			
def Terror(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op19)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
			
def Western(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op20)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
			
def Spain():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op21)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
def Superheroes():

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op22)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
def Sagas(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op23)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url, id, trailer in match:
		try:
			m3u_playlist(name, url, thumb, id, trailer)
			
		except:
			pass
			
def video_tutoriales(): 

## Obtiene la lista m3u que hayamos creado para una categoria.
	content = make_request(op25)
	match = re.compile(tutoriales_regex).findall(content)
	for thumb, name, url in match:
		try:
			m3u_videotutoriales(thumb, name, url)
			
		except:
			pass


def playlist(thumb, name, url, id):	

	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')			
			add_dir(name, url, '', thumb, thumb)			
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		if 'youtube.com/watch?v=' in url:
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % (url.split('=')[-1])
		elif 'dailymotion.com/video/' in url:
			url = url.split('/')[-1].split('_')[0]
			url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	
		else:			
			url = url
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			add_link(name, url, 1, thumb, thumb)			
		else:				
			add_link(name, url, 1, icon, fanart)	

def m3u_videotutoriales(thumb, name, url):	
## despues de obtener las url de la lista m3u las muestra.
	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		name = '[COLOR white]%s[/COLOR]' % name
			
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			
			add_video(name, url, 4, iconimage, fanart)

		else:
		
			add_video(name, url, 4, iconimage, fanart)			
			
def m3u_playlist(name, url, thumb, id, trailer):	
## despues de obtener las url de la lista m3u las muestra.
			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	trailer = trailer.replace('"', ' ').replace('&amp;', '&').strip()
		
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		
			if '[Rapidvideo]' in name:
                
			    name = '[COLOR gold]%s[/COLOR]' % name
			if '[rapidvideo]' in name:

			    name = '[COLOR gold]%s[/COLOR]' % name
			elif '[streamago]' in name:

				name = '[COLOR gold]%s[/COLOR]' % name
			elif '[Streamgo]' in name:

				name = '[COLOR gold]%s[/COLOR]' % name
			elif '[Openload]' in name:

				name = '[COLOR red]%s[/COLOR] [PAIR]' % name
			elif '[openload]' in name:

				name = '[COLOR red]%s[/COLOR] [PAIR]' % name
			elif '[Vidoza]' in name:

				name = '[COLOR gold]%s[/COLOR]' % name
			elif '[vidoza]' in name:
 
				name = '[COLOR gold]%s[/COLOR]' % name
			elif '[Streamcloud]' in name:

				name = '[COLOR gold]%s[/COLOR]' % name
			elif '[streamcloud]' in name:

				name = '[COLOR gold]%s[/COLOR]' % name
				
			elif '[streamcherry]' in name:

				name = '[COLOR gold]%s[/COLOR]' % name
				
			elif '[Streamcherry]' in name:

				name = '[COLOR gold]%s[/COLOR]' % name
				
			elif '[Okru]' in name:

				name = '[COLOR gold]%s[/COLOR]' % name
			elif '[okru]' in name:

				name = '[COLOR gold]%s[/COLOR]' % name
			elif '[Multi enlace]' in name:

				name = '[COLOR gold]%s[/COLOR]' % name
			elif '[4k]' in name:

				name = '[COLOR gold]%s[/COLOR]' % name
			elif '[sd]' in name:

				name = '[COLOR gold]%s[/COLOR]' % name
			elif '[hd]' in name:

				name = '[COLOR gold]%s[/COLOR]' % name
			elif '[Youtube]' in name:

				name = '[COLOR white]%s[/COLOR]' % name
			elif '[Realstream]' in name:

				name = '[COLOR gold]%s[/COLOR]' % name
			else:

				name = '[COLOR white]%s[/COLOR]' % name
			
			if 'tvg-logo' in thumb:				
				thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			
				add_link(name, url, 1, thumb, thumb, id, trailer)

			else:
		
				add_link(name, url, 1, thumb, thumb, id, trailer)			
            
def play_video(name,trailer):
    
    
		url = 'plugin://plugin.video.youtube/play/?video_id=%s' % trailer
		media_url = url
		item = xbmcgui.ListItem(name, trailer, path = media_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
		return

	
def PLAYVIDEO(name,url):
    import urlresolver
    from urlresolver import common

    hmf = urlresolver.HostedMediaFile(url)

    if not hmf:
            xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" +name+ "[/COLOR] ,7500)")

            return False


    try:
        stream_url = hmf.resolve()
        if not stream_url or not isinstance(stream_url, basestring):
            try: msg = stream_url.msg
            except: msg = url
            raise Exception(msg)
    except Exception as e:
        try: msg = str(e)
        except: msg = url
        xbmc.executebuiltin("XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" +name+ "[/COLOR] ,7500)")            

        return False
   
    notificar = addon.getSetting('notificar') 	
    if notificar == 'true':
        xbmc.executebuiltin("XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" +name+ "[/COLOR] ,7500)")	
    listitem = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
	
def PLAYVIDEO2(name,url):


	if 'https://www.rapidvideo.com/v/' in url:
				
		content = make_request(url)
		match = re.compile('rapidvideo').findall(content)
		for url in match:
		
			
			try:
				notificar = addon.getSetting('notificar')
				if notificar == 'true':
					xbmc.executebuiltin("XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" +name+ "[/COLOR] ,7500)")	
				listitem = xbmcgui.ListItem(path = url)
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)	
				
			except: xbmc.executebuiltin("XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" +name+ "[/COLOR] ,7500)")  
		
	
	else:
	
		import urlresolver
		from urlresolver import common
    
		hmf = urlresolver.HostedMediaFile(url)

		if not hmf:
			xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" +name+ "[/COLOR] ,7500)")
			return False


		try:
			stream_url = hmf.resolve()
			if not stream_url or not isinstance(stream_url, basestring):
				try: msg = stream_url.msg
				except: msg = url
				raise Exception(msg)
		except Exception as e:
			try: msg = str(e)
			except: msg = url
			xbmc.executebuiltin("XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" +name+ "[/COLOR] ,7500)")            
			return False
   
		notificar = addon.getSetting('notificar')
		if notificar == 'true':
			xbmc.executebuiltin("XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" +name+ "[/COLOR] ,7500)")	
		listitem = xbmcgui.ListItem(path=stream_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
		
	return


	
def PLAYVIDEO3(name,url):

	if '[Youtube]' in name:
		
		url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
			
		try:
			notificar = addon.getSetting('notificar')
			if notificar == 'true':
				xbmc.executebuiltin("XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" +name+ "[/COLOR] ,7500)")	
				listitem = xbmcgui.ListItem(path = url)
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)	
				
		except: xbmc.executebuiltin("XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" +name+ "[/COLOR] ,7500)")  

		
	else:
	
		import urlresolver
		from urlresolver import common
    
		hmf = urlresolver.HostedMediaFile(url)

		if not hmf:
			xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" +name+ "[/COLOR] ,7500)")
			return False


		try:
			stream_url = hmf.resolve()
			if not stream_url or not isinstance(stream_url, basestring):
				try: msg = stream_url.msg
				except: msg = url
				raise Exception(msg)
		except Exception as e:
			try: msg = str(e)
			except: msg = url
			xbmc.executebuiltin("XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" +name+ "[/COLOR] ,7500)")            
			return False
   
		notificar = addon.getSetting('notificar')
		if notificar == 'true':
			xbmc.executebuiltin("XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" +name+ "[/COLOR] ,7500)")	
		listitem = xbmcgui.ListItem(path=stream_url)
		xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
		
	return

def PLAYVIDEO4(name,url):


	if '[Youtube]' in name:
		
		url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
			
		try:
			notificar = addon.getSetting('notificar')
			if notificar == 'true':
				xbmc.executebuiltin("XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" +name+ "[/COLOR] ,7500)")	
				listitem = xbmcgui.ListItem(path = url)
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)	
				
			
				
		except: xbmc.executebuiltin("XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" +name+ "[/COLOR] ,7500)")  

		
	else:
	
		import xbmcgui
		import urlresolver
		from urlresolver import common
    
		hmf = urlresolver.HostedMediaFile(url)

		if not hmf:
			xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" +name+ "[/COLOR] ,7500)")
			return False
		
		import resolveurl as urlresolver
		
		hmf = urlresolver.HostedMediaFile(url)
		
		
		if not hmf:
			xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" +name+ "[/COLOR] ,7500)")
			return False

		try:
			stream_url = hmf.resolve()
			if not stream_url or not isinstance(stream_url, basestring):
				try: msg = stream_url.msg
				except: msg = url
				raise Exception(msg)
		except Exception as e:
			try: msg = str(e)
			except: msg = url
			xbmc.executebuiltin("XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" +name+ "[/COLOR] ,7500)")            
			return False
				
		
			
		notificar = addon.getSetting('notificar')
		if notificar == 'true':
			xbmc.executebuiltin("XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" +name+ "[/COLOR] ,7500)")

			if '[Realstream]' in name:
		
				restante = addon.getSetting('restante')
				if restante == 'true':
					dialog = xbmcgui.Dialog()
					ok = dialog.ok("[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]")
   
			listitem = xbmcgui.ListItem(path=stream_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
		
		
		
	return
	
def PLAYVIDEO5(name,url):


	if '[Youtube]' in name:
		
		url = 'plugin://plugin.video.youtube/play/?video_id=%s' % url
			
		try:
			notificar = addon.getSetting('notificar')
			if notificar == 'true':
				xbmc.executebuiltin("XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" +name+ "[/COLOR] ,7500)")	
				listitem = xbmcgui.ListItem(path = url)
				xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)	
				
			
				
		except: xbmc.executebuiltin("XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado, tiempo excedido en servidor. Utilíza una vpn o apaga el router 5 min.[/COLOR] [COLOR orange]" +name+ "[/COLOR] ,7500)")  

		
	else:
		
		import resolveurl
		
		hmf = urlresolver.HostedMediaFile(url)
		
		
		if not hmf:
			xbmc.executebuiltin("XBMC.Notification(Real Stream, Enlace no soportado para: [COLOR orange]" +name+ "[/COLOR] ,7500)")
			return False

		try:
			stream_url = hmf.resolve()
			if not stream_url or not isinstance(stream_url, basestring):
				try: msg = stream_url.msg
				except: msg = url
				raise Exception(msg)
		except Exception as e:
			try: msg = str(e)
			except: msg = url
			xbmc.executebuiltin("XBMC.Notification(Real Stream, [COLOR red]Enlace no encontrado:[/COLOR] [COLOR orange]" +name+ "[/COLOR] ,7500)")            
			return False
				
		
			
		notificar = addon.getSetting('notificar')
		if notificar == 'true':
			xbmc.executebuiltin("XBMC.Notification(Real Stream,[COLOR lime] reproduciendo: [/COLOR][COLOR orange]" +name+ "[/COLOR] ,7500)")

			if '[Realstream]' in name:
		
				restante = addon.getSetting('restante')
				if restante == 'true':
					dialog = xbmcgui.Dialog()
					ok = dialog.ok("[COLOR orange]Real Stream: (Restriccion por IP del Servidor)[/COLOR]" , "[COLOR gold]Tiempo maximo de uso del servidor Realstream es de [/COLOR][COLOR lime]120 min. [/COLOR] [COLOR blue]Con tu actual IP.[/COLOR]" , "[COLOR gold]una vez finalizado puedes Apagar tu router y esperar 5 min.[/COLOR]" , "[COLOR gold]Tambien puedes utilizar una VPN para cambiar tu ip pública. Esto te dará otras dos horas de uso.[/COLOR]")
   
			listitem = xbmcgui.ListItem(path=stream_url)
			xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
		
		
		
	return
	
def get_params():
## Codigo de shani de Live Stream Pro Con este script se obtienen los parametros. Sino sabes ... dejalo como lo puso Shani que asi funciona.

	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param
	

def resolver_settings():
    try:
        import resolveurl
        xbmcaddon.Addon('script.module.resolveurl').openSettings()
    except:
        import urlresolver
        xbmcaddon.Addon('script.module.urlresolver').openSettings()

def ThemovieDB():
    dialog = xbmcgui.Dialog()
    list = (
        opc1,
        opc2
        )
        
    call = dialog.select('[B][COLOR=orange]The Movie db[/COLOR][/B]', [
	'[COLOR=gold]Accede a themoviedb.com[/COLOR]', 
    
	'[B][COLOR=white]                           Volver al Menu [/COLOR][/B]',])

    if call:
        # esc is not pressed
        if call < 0:
            return
        func = list[call-2]
        return func()
    else:
        func = list[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def opc1():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.themoviedb.org/movie/' ) )
    else:
        opensite = webbrowser . open('https://www.themoviedb.org/movie/')

        
def opc2():

    main()
	
	
	
def PAIR():
    dialog = xbmcgui.Dialog()
    funcs = (
        functionA,
        functionB
        )
        
    call = dialog.select('[B][COLOR=yellow]Autoriza tu dispositivo[/COLOR][/B]', [
	'[COLOR=orange]                       Pair OpenLoad [/COLOR]', 
    
	'[B][COLOR=lime]                           Volver al Menu [/COLOR][/B]',])

    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def functionA():
    if myplatform == 'android': # Android 
        opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://olpair.com/' ) )
    else:
        opensite = webbrowser . open('https://olpair.com/')

        
def functionB():

    main()
	

def selector(name,url,id,trailer):
    dialog = xbmcgui.Dialog()
    funcs = (
        function1,
		play_trailer,
		function2,
		ThemovieDB
        )
        
    call = dialog.select('[COLOR=yellow]REAL STREAM MENU:[/COLOR]', [
	
	'[COLOR=yellow]Reproducir [/COLOR] [COLOR orange]' +name+ '[/COLOR]', 
	
	'[COLOR=yellow]Reproducir Trailer de: [/COLOR][COLOR orange]' +name+ '[/COLOR]',
    
	'[COLOR=yellow]      Mas Informacion, ver trailers  [/COLOR]',
	
	'[COLOR orange]        Accede a la web MovieDB[/COLOR]'])

    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-4]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def function1():
    
	PLAYVIDEO5(name,url)
	
def play_trailer():

	play_video(name,trailer)
	
	
def function2():
    
    if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
	movie_id = id
	
	xbmc.executebuiltin( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % movie_id )

    if notificar == 'true':	
	
		xbmc.executebuiltin("XBMC.Notification(Extended Info,Abriendo: [COLOR green]" +name+ "[/COLOR] ,5000)")

	
def goThemovieDB():

    ThemovieDB()


		
def add_dir(name, url, mode, iconimage, fanart):
## Añadre los directorios del menu. Con sus respetivos iconos y fanart y los enlaces a las acciones a enprender por el addon.
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
	ok = True
	liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		u = 'plugin://plugin.video.youtube/%s/%s/' % (url.split( '/' )[-2], url.split( '/' )[-1])
		ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
		return ok		
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
	return ok
	
def add_link(name, url, mode, iconimage, fanart, id, trailer):

	try:
            name = name.encode('utf-8')
        except: pass
	commands=[]
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&id=" + str(id) + "&trailer=" + urllib.quote_plus(trailer)
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	
	if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
		commands.append(("[B][COLOR yellow]ExtendedInfo[/COLOR][/B]","XBMC.RunScript(script.extendedinfo,info=extendedinfo,name=%s,id=%s)" % (name,id) ))	
		liz.addContextMenuItems(commands, replaceItems=True)
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)
	return ok
	
def add_video(name, url, mode, iconimage, fanart):

	try:
            name = name.encode('utf-8')
        except: pass
	
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage) + "&id=" + str(id)
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)
	return ok
	
	
def buscar_themovieid(): 

## ESTA FUNCION BUSCA EN LAS LISTAS m3u DENTRO DE LAS CATEGORIAS. | Cuantas mas categorias, mas lento ira el buscador a no ser que hagamos buscadores individuales.

		keyb = xbmc.Keyboard('', 'Escriba id de la pelicula: Themoviedb.org')
		keyb.doModal()
		if (keyb.isConfirmed()):
		
			searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
			
			if xbmc.getCondVisibility('System.HasAddon(script.extendedinfo)'):
			    try:
				    
				xbmc.executebuiltin( "RunScript(script.extendedinfo,info=extendedinfo,id=%s)" % searchText )

				if notificar == 'true':	
	
					xbmc.executebuiltin("XBMC.Notification(Extended Info,Abriendo: [COLOR green]" +name+ "[/COLOR] ,10000)")
		    
			    except:
				    
					xbmcgui.Dialog().ok("El Script ExtendedInfo No esta instalado" , "[COLOR cyan]Necesario AddOn externo para ver informacion de peliculas[/COLOR]","[COLOR yellow]AddOns -> Instalar desde repositorio -> KODI add-on repository -> Add-ons de programas -> ExtendedInfo Script\n[COLOR lime]Despues de instalarlo configuralo para español.[/COLOR]")     
	
		
   	
params = get_params()
url = None
name = None
mode = None
iconimage = None
id = None
trailer = None

xbmcplugin.setContent(int(sys.argv[1]), 'movies')

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass 
try:
	id = int(params["id"])
except:
	pass 
try:
	trailer = urllib.unquote_plus(params["trailer"])
except:
	pass 
	

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)
print "iconimage: " + str(iconimage)
print "id: " + str(id)
print "trailer: " + str(trailer)

if mode == None or url == None or len(url) < 1:
	menu()
	favoritos()
	check_version()
	aviso = addon.getSetting('aviso')
	if aviso == 'true':
		mensaje()

elif mode == 1:
    selector(name,url,id,trailer)
elif mode == 2:
    Novedades()
elif mode == 3:
	Estrenos()
elif mode == 4:
    PLAYVIDEO(name,url)
elif mode == 5:
    Accion()
elif mode == 6:
    Animacion()
elif mode == 7:
    Aventuras()
elif mode == 8:
    Belico()
elif mode == 9:
    Cifi()
elif mode == 10:
    Comedia()
elif mode == 11:
    Crimen()
elif mode == 12:
    Drama()
elif mode == 13:
    Familiar()
elif mode == 14:
    Fantasia()
elif mode == 15:
    Historia()
elif mode == 16:
    Misterio()
elif mode == 17:
    Musical()
elif mode == 18:
    Romance()
elif mode == 19:
    Thriller()
elif mode == 20:
    Suspense()
elif mode == 21:
    Terror()
elif mode == 22:
    Western()
elif mode == 23:
    Spain()
elif mode == 24:
    Superheroes()
elif mode == 25:
    Sagas()
elif mode == 98:
    busqueda_global()
elif mode == 97:
    PAIR()
elif mode == 99:
    get_info_movie()
elif mode == 100:
    menu_player(name,url)
elif mode == 111:
    search()
elif mode == 115:
    play_video(url) 
elif mode == 116:
    peliculas()	
elif mode == 119:
    Real_stream_settings()
elif mode == 120:
    urlresolver_settings()    
elif mode == 121:
    favoritos() 
elif mode == 125:
    video_tutoriales()
elif mode == 126:
    torrentPro()
elif mode == 127:
    buscar_themovieid()
elif mode == 128:
	TESTLINKS()
elif mode == 140:
	resolveurl_settings()

xbmcplugin.endOfDirectory(plugin_handle)			