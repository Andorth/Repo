# -*- coding: utf-8 -*-

""" FIRETV by Netai Team 2020 """
import urllib
import urllib2
import re
import os
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import traceback
import cookielib,base64
import codecs
import xbmc
import sys
import script
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP

script.getSources()